# Jembatan JavaScript harus tetap ada (dipanggil dari shield.js dan home.html)
-keepattributes JavascriptInterface
-keepclassmembers class id.minibrowser.shield.MainActivity$Bridge {
    @android.webkit.JavascriptInterface <methods>;
}
-keepclassmembers class id.minibrowser.shield.MainActivity$HomeBridge {
    @android.webkit.JavascriptInterface <methods>;
}
