package id.minibrowser.shield

import android.util.Base64
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.URL
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import kotlin.concurrent.thread

/**
 * DNS aman lewat DNS-over-HTTPS (DoH).
 *
 * WebView tidak bisa diberi DNS sendiri, jadi aplikasi menjalankan proxy kecil di
 * 127.0.0.1. Semua lalu lintas WebView diarahkan ke proxy itu (ProxyController), dan
 * proxy mencari alamat IP lewat DoH, bukan lewat DNS operator. Lalu lintas HTTPS
 * tetap terenkripsi ujung ke ujung: proxy hanya meneruskan terowongan (CONNECT),
 * tidak bisa membaca isinya.
 */
object SecureDns {

    data class Provider(val id: String, val name: String, val desc: String, val url: String?)

    /** Hanya layanan tanpa pemaksaan SafeSearch. Varian "Family" sengaja tidak dimasukkan. */
    val providers = listOf(
        Provider("system", "Sistem (bawaan HP)", "Ikut DNS operator, SafeSearch bisa dipaksa", null),
        Provider("cloudflare", "Cloudflare 1.1.1.1", "Cepat, tanpa filter", "https://cloudflare-dns.com/dns-query"),
        Provider("cloudflare-sec", "Cloudflare Security 1.1.1.2", "Blokir situs malware", "https://security.cloudflare-dns.com/dns-query"),
        Provider("adguard", "AdGuard DNS", "Blokir iklan dan pelacak", "https://dns.adguard-dns.com/dns-query"),
        Provider("adguard-nf", "AdGuard Tanpa Filter", "Tanpa blokir apa pun", "https://unfiltered.adguard-dns.com/dns-query"),
        Provider("google", "Google 8.8.8.8", "Stabil, tanpa filter", "https://dns.google/dns-query"),
        Provider("quad9", "Quad9 9.9.9.9", "Nirlaba, blokir malware", "https://dns.quad9.net/dns-query"),
        Provider("mullvad", "Mullvad DNS", "Fokus privasi, tanpa log", "https://dns.mullvad.net/dns-query"),
        Provider("mullvad-ad", "Mullvad Adblock", "Privasi + blokir iklan", "https://adblock.dns.mullvad.net/dns-query")
    )

    fun byId(id: String?) = providers.firstOrNull { it.id == id } ?: providers[1]

    @Volatile var endpoint: String? = null
    /** Jumlah pencarian DoH yang gagal sejak penyedia dipilih (untuk info di pengaturan). */
    @Volatile var failures = 0
    @Volatile var lookups = 0

    private val cache = ConcurrentHashMap<String, Pair<List<InetAddress>, Long>>()
    /** Banyak koneksi paralel ke host yang sama cukup satu kueri DoH. */
    private val inflight = ConcurrentHashMap<String, java.util.concurrent.FutureTask<List<InetAddress>>>()

    fun select(p: Provider) {
        endpoint = p.url
        cache.clear()
        failures = 0
        lookups = 0
    }

    // ------------------------------------------------------------------ resolver

    fun resolve(host: String): List<InetAddress> {
        if (isIpLiteral(host)) return listOf(InetAddress.getByName(host))
        val ep = endpoint ?: return InetAddress.getAllByName(host).toList()
        val now = System.currentTimeMillis()
        cache[host]?.let { if (it.second > now) return it.first }
        return try {
            val task = java.util.concurrent.FutureTask {
                lookups++
                var list = query(ep, host, 1)
                if (list.isEmpty()) list = query(ep, host, 28)
                if (list.isEmpty()) throw IllegalStateException("tidak ada alamat")
                if (cache.size > 2000) cache.clear()
                cache[host] = list to System.currentTimeMillis() + 10 * 60 * 1000
                list
            }
            val existing = inflight.putIfAbsent(host, task)
            val run = existing ?: task
            if (existing == null) try { task.run() } finally { inflight.remove(host) }
            run.get()
        } catch (e: Exception) {
            failures++
            // DoH gagal (mis. diblokir jaringan): pakai DNS sistem supaya halaman tetap terbuka
            InetAddress.getAllByName(host).toList()
        }
    }

    private fun isIpLiteral(h: String) =
        h.matches(Regex("^\\d{1,3}(\\.\\d{1,3}){3}$")) || h.contains(':')

    /** Kueri RFC 8484 (metode GET, format wire). type 1 = A, 28 = AAAA. */
    private fun query(endpoint: String, host: String, type: Int): List<InetAddress> {
        val q = Base64.encodeToString(buildQuery(host, type), Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP)
        val c = URL("$endpoint?dns=$q").openConnection() as HttpURLConnection
        c.connectTimeout = 5000
        c.readTimeout = 5000
        c.setRequestProperty("Accept", "application/dns-message")
        try {
            if (c.responseCode != 200) throw IllegalStateException("HTTP ${c.responseCode}")
            return parseAnswer(c.inputStream.use { it.readBytes() }, type)
        } finally {
            c.disconnect()
        }
    }

    fun buildQuery(host: String, type: Int): ByteArray {
        val o = ByteArrayOutputStream()
        o.write(byteArrayOf(0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0)) // id=0, RD=1, 1 pertanyaan
        host.trimEnd('.').split('.').forEach { label ->
            val b = label.toByteArray(Charsets.US_ASCII)
            o.write(b.size)
            o.write(b)
        }
        o.write(0)
        o.write(type shr 8); o.write(type and 0xFF)
        o.write(0); o.write(1) // kelas IN
        return o.toByteArray()
    }

    fun parseAnswer(b: ByteArray, type: Int): List<InetAddress> {
        fun u16(i: Int) = ((b[i].toInt() and 0xFF) shl 8) or (b[i + 1].toInt() and 0xFF)
        fun skipName(start: Int): Int {
            var i = start
            while (true) {
                val len = b[i].toInt() and 0xFF
                if (len and 0xC0 == 0xC0) return i + 2
                if (len == 0) return i + 1
                i += len + 1
            }
        }
        if (b.size < 12) return emptyList()
        val rcode = b[3].toInt() and 0x0F
        if (rcode != 0) return emptyList()
        val qd = u16(4)
        val an = u16(6)
        var i = 12
        repeat(qd) { i = skipName(i) + 4 }
        val out = ArrayList<InetAddress>()
        repeat(an) {
            i = skipName(i)
            val t = u16(i)
            val len = u16(i + 8)
            val data = i + 10
            if (t == type && ((t == 1 && len == 4) || (t == 28 && len == 16))) {
                out.add(InetAddress.getByAddress(b.copyOfRange(data, data + len)))
            }
            i = data + len
        }
        return out
    }

    // ------------------------------------------------------------------ proxy lokal

    private var server: ServerSocket? = null
    private val pool = Executors.newCachedThreadPool { r -> Thread(r, "mb-proxy").apply { isDaemon = true } }

    /** Menyalakan proxy (sekali saja) dan mengembalikan nomor port-nya. */
    @Synchronized
    fun startProxy(): Int {
        server?.let { return it.localPort }
        val s = ServerSocket(0, 64, InetAddress.getByName("127.0.0.1"))
        server = s
        thread(isDaemon = true, name = "mb-proxy-accept") {
            while (!s.isClosed) {
                try {
                    val c = s.accept()
                    pool.execute { handle(c) }
                } catch (_: Exception) {}
            }
        }
        return s.localPort
    }

    private fun handle(client: Socket) {
        var upstream: Socket? = null
        try {
            client.soTimeout = 20000
            client.tcpNoDelay = true
            val cin = client.getInputStream()
            val head = readHead(cin) ?: return client.close()
            val text = String(head, Charsets.ISO_8859_1)
            val lines = text.split("\r\n")
            val parts = lines[0].split(" ")
            if (parts.size < 3) return client.close()
            val method = parts[0]
            val target = parts[1]

            if (method.equals("CONNECT", true)) {
                val (host, port) = splitHostPort(target, 443)
                upstream = connect(host, port)
                client.getOutputStream().apply {
                    write("HTTP/1.1 200 Connection Established\r\n\r\n".toByteArray(Charsets.ISO_8859_1))
                    flush()
                }
            } else {
                // HTTP biasa: "GET http://host/path HTTP/1.1"
                val u = URL(target)
                val port = if (u.port > 0) u.port else 80
                upstream = connect(u.host, port)
                val path = (u.file ?: "").ifEmpty { "/" }
                val sb = StringBuilder("$method $path ${parts[2]}\r\n")
                for (h in lines.drop(1)) {
                    if (h.isEmpty()) continue
                    val k = h.substringBefore(':').trim().lowercase()
                    if (k == "proxy-connection" || k == "connection" || k == "keep-alive") continue
                    sb.append(h).append("\r\n")
                }
                // satu permintaan per koneksi, supaya tidak tertukar host
                sb.append("Connection: close\r\n\r\n")
                upstream.getOutputStream().apply { write(sb.toString().toByteArray(Charsets.ISO_8859_1)); flush() }
            }

            client.soTimeout = 0
            val up = upstream
            pool.execute { pipe(up.getInputStream(), client.getOutputStream(), client, up) }
            pipe(cin, up.getOutputStream(), client, up)
        } catch (_: Exception) {
            try { client.close() } catch (_: Exception) {}
            try { upstream?.close() } catch (_: Exception) {}
        }
    }

    private fun connect(host: String, port: Int): Socket {
        val addrs = resolve(host).sortedBy { if (it is Inet4Address) 0 else 1 }
        var last: Exception? = null
        for (a in addrs) {
            try {
                val s = Socket()
                s.tcpNoDelay = true
                s.connect(InetSocketAddress(a, port), 10000)
                return s
            } catch (e: Exception) { last = e }
        }
        throw last ?: IllegalStateException("tidak bisa terhubung ke $host")
    }

    private fun splitHostPort(s: String, def: Int): Pair<String, Int> {
        if (s.startsWith("[")) {
            val end = s.indexOf(']')
            val host = s.substring(1, end)
            val port = s.substring(end + 1).removePrefix(":").toIntOrNull() ?: def
            return host to port
        }
        val i = s.lastIndexOf(':')
        return if (i > 0) s.substring(0, i) to (s.substring(i + 1).toIntOrNull() ?: def) else s to def
    }

    /** Membaca kepala permintaan sampai baris kosong. Maks 64 KB. */
    private fun readHead(inp: InputStream): ByteArray? {
        val o = ByteArrayOutputStream()
        var m = 0
        while (o.size() < 65536) {
            val c = inp.read()
            if (c < 0) return null
            o.write(c)
            m = when {
                c == '\r'.code -> if (m == 2) 3 else 1
                c == '\n'.code && (m == 1 || m == 3) -> m + 1
                else -> 0
            }
            if (m == 4) return o.toByteArray()
        }
        return null
    }

    private fun pipe(i: InputStream, o: OutputStream, a: Socket, b: Socket) {
        val buf = ByteArray(16384)
        try {
            while (true) {
                val n = i.read(buf)
                if (n < 0) break
                o.write(buf, 0, n)
                o.flush()
            }
        } catch (_: Exception) {
        } finally {
            try { a.close() } catch (_: Exception) {}
            try { b.close() } catch (_: Exception) {}
        }
    }
}
