package id.minibrowser.shield

import android.content.Context
import android.widget.ScrollView

/** ScrollView yang tingginya mengikuti isi, tapi tidak melebihi batas. */
class MaxHeightScrollView(ctx: Context, private val maxH: Int) : ScrollView(ctx) {
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, MeasureSpec.makeMeasureSpec(maxH, MeasureSpec.AT_MOST))
    }
}
