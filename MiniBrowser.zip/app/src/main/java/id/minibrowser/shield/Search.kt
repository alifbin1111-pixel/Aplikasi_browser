package id.minibrowser.shield

import android.net.Uri

/** Mesin pencari, wilayah hasil, dan SafeSearch. */
object Search {
    val engines = listOf("google" to "Google", "bing" to "Bing", "ddg" to "DuckDuckGo", "brave" to "Brave")

    val regions = listOf(
        "SG" to "Singapura", "ID" to "Indonesia", "MY" to "Malaysia", "US" to "Amerika Serikat",
        "GB" to "Inggris", "JP" to "Jepang", "KR" to "Korea Selatan", "AU" to "Australia",
        "IN" to "India", "" to "Global (tanpa wilayah)"
    )

    private val DDG = mapOf(
        "SG" to "sg-en", "ID" to "id-en", "MY" to "my-en", "US" to "us-en", "GB" to "uk-en",
        "JP" to "jp-jp", "KR" to "kr-kr", "AU" to "au-en", "IN" to "in-en"
    )

    fun engineName(id: String) = engines.firstOrNull { it.first == id }?.second ?: "Google"
    fun regionName(code: String) = regions.firstOrNull { it.first == code }?.second ?: "Singapura"

    fun url(engine: String, region: String, safe: Boolean, query: String): String {
        val q = Uri.encode(query)
        val r = region.lowercase()
        return when (engine) {
            "bing" -> "https://www.bing.com/search?q=$q&adlt=" + (if (safe) "strict" else "off") +
                (if (region.isNotEmpty()) "&cc=$region" else "")
            "ddg" -> "https://duckduckgo.com/?q=$q&kp=" + (if (safe) "1" else "-2") +
                "&kl=" + (DDG[region] ?: "wt-wt")
            "brave" -> "https://search.brave.com/search?q=$q&safesearch=" + (if (safe) "strict" else "off") +
                (if (region.isNotEmpty()) "&country=$r" else "")
            else -> "https://www.google.com/search?q=$q&safe=" + (if (safe) "active" else "off") +
                (if (region.isNotEmpty()) "&gl=$r" else "")
        }
    }

    /** Untuk bilah alamat: tampilkan kata kunci kalau halaman ini hasil pencarian. */
    fun queryOf(url: String?): String? {
        if (url == null) return null
        val u = Uri.parse(url)
        val h = u.host ?: return null
        val isSearch = (h.contains("google.") && u.path == "/search") ||
            (h.endsWith("bing.com") && u.path == "/search") ||
            h.endsWith("duckduckgo.com") || h == "search.brave.com"
        return if (isSearch) try { u.getQueryParameter("q") } catch (_: Exception) { null } else null
    }
}
