package id.minibrowser.shield

import android.content.Context
import android.net.Uri
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Pemblokir level jaringan: setiap permintaan WebView dicek di sini
 * sebelum dikirim, jadi iklan tidak pernah sempat dimuat.
 */
object AdBlocker {

    private val BUILT_IN = setOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com", "google-analytics.com",
        "adservice.google.com", "2mdn.net", "adnxs.com", "taboola.com", "outbrain.com", "popads.net",
        "popcash.net", "propellerads.com", "adsterra.com", "exoclick.com", "juicyads.com", "mgid.com",
        "adskeeper.com", "revcontent.com", "criteo.com", "criteo.net", "pubmatic.com", "rubiconproject.com",
        "openx.net", "amazon-adsystem.com", "moatads.com", "scorecardresearch.com", "adsrvr.org",
        "smartadserver.com", "yieldmo.com", "adform.net", "casalemedia.com", "advertising.com",
        "bidswitch.net", "teads.tv", "zedo.com", "clickadu.com", "hilltopads.net", "a-ads.com",
        "coinzilla.com", "bitmedia.io", "monetag.com", "admaven.com", "adcolony.com", "applovin.com",
        "hotjar.com", "quantserve.com",
        "onclickads.net", "onclkds.com", "onclasrv.com", "propellerclick.com", "popmyads.com",
        "popunder.net", "adcash.com", "adsco.re", "trafficjunky.net", "trafficstars.com",
        "tsyndicate.com", "exosrv.com", "realsrv.com", "magsrv.com", "bidgear.com",
        "highperformanceformat.com", "highperformancecpm.com", "highperformancegate.com",
        "profitablecpmgate.com", "profitabledisplaynetwork.com", "effectiveratecpm.com",
        "effectivegatecpm.com", "toprevenuegate.com", "displayvertising.com", "adsterratools.com",
        "dtscout.com", "dtscdn.com", "histats.com", "mc.yandex.ru", "yandexadexchange.net",
        "pushwhy.com", "pushnest.com", "richpartners.co", "clickaine.com", "galaksion.com",
        "pemsrv.com", "acscdn.com", "ad-maven.com", "wpadmngr.com", "notifpush.com"
    )

    /** Daftar komunitas (adware + malware) yang diunduh sekali seminggu. */
    private const val LIST_URL = "https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts"
    private const val FILE = "hosts.txt"

    private val PATH = Regex(
        """/(pagead|adserver|adsbygoogle|prebid|adframe)/|[/_.-]ads?\.js|[?&](adunit|ad_slot)=|pop-?under|clickunder""",
        RegexOption.IGNORE_CASE
    )
    private val ANTI = Regex(
        """fuckadblock|blockadblock|adblock[-_.]?(detect|killer|checker)|detect[-_.]?adblock|anti[-_.]?adblock|adblockdetector""",
        RegexOption.IGNORE_CASE
    )

    @Volatile
    private var hosts: Set<String> = BUILT_IN

    val size: Int get() = hosts.size

    fun load(ctx: Context) {
        val f = File(ctx.filesDir, FILE)
        if (f.exists()) hosts = BUILT_IN + parse(f.readLines())
    }

    fun needsUpdate(ctx: Context): Boolean {
        val f = File(ctx.filesDir, FILE)
        return !f.exists() || System.currentTimeMillis() - f.lastModified() > 7L * 24 * 3600 * 1000
    }

    /** Mengunduh daftar terbaru. Mengembalikan jumlah domain. Jalankan di thread latar. */
    fun update(ctx: Context): Int {
        val c = URL(LIST_URL).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 30000
        try {
            if (c.responseCode != 200) throw IllegalStateException("HTTP ${c.responseCode}")
            val lines = c.inputStream.bufferedReader().readLines()
            val set = parse(lines)
            if (set.size < 1000) throw IllegalStateException("daftar terlalu kecil")
            File(ctx.filesDir, FILE).writeText(set.joinToString("\n"))
            hosts = BUILT_IN + set
            return hosts.size
        } finally {
            c.disconnect()
        }
    }

    private fun parse(lines: List<String>): Set<String> {
        val out = HashSet<String>(lines.size)
        for (raw in lines) {
            val line = raw.substringBefore('#').trim()
            if (line.isEmpty()) continue
            val parts = line.split(Regex("\\s+"))
            val host = when {
                parts.size >= 2 && (parts[0] == "0.0.0.0" || parts[0] == "127.0.0.1") -> parts[1]
                parts.size == 1 -> parts[0]
                else -> continue
            }.lowercase()
            if (host.contains('.') && host != "0.0.0.0" && !host.startsWith("localhost")) out.add(host)
        }
        return out
    }

    /** Cocok untuk host itu sendiri dan semua induknya: a.b.iklan.com -> iklan.com */
    fun isBlockedHost(host: String?): Boolean {
        if (host.isNullOrEmpty()) return false
        var h = host.lowercase()
        val set = hosts
        while (true) {
            if (h in set) return true
            val i = h.indexOf('.')
            if (i < 0) return false
            h = h.substring(i + 1)
        }
    }

    fun isBlocked(url: String): Boolean {
        val u = Uri.parse(url)
        if (isBlockedHost(u.host)) return true
        val s = (u.encodedPath ?: "") + "?" + (u.encodedQuery ?: "")
        return PATH.containsMatchIn(s) || ANTI.containsMatchIn(s)
    }

    /** Perkiraan domain utama: sub.situs.co.id -> situs.co.id */
    fun reg(host: String?): String {
        if (host.isNullOrEmpty()) return ""
        val p = host.lowercase().removePrefix("www.").split('.')
        val n = if (p.size > 2 && p[p.size - 2] in SLD) 3 else 2
        return p.takeLast(n).joinToString(".")
    }

    private val SLD = setOf("co", "com", "ac", "or", "go", "net", "org", "gov", "edu", "sch", "my", "web", "biz", "ne")
}
