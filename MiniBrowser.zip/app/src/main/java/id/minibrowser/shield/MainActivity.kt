package id.minibrowser.shield

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.os.SystemClock
import android.text.InputType
import android.text.SpannableString
import android.text.style.RelativeSizeSpan
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.util.UUID
import java.util.concurrent.atomic.AtomicInteger
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private companion object {
        const val HOME = "file:///android_asset/home.html"
        val SPEEDS = intArrayOf(12, 20, 30, 45, 65, 90, 125, 170, 230, 300)
        val BG = 0xFF17191E.toInt()
        val SF = 0xFF1F2228.toInt()
        val SF2 = 0xFF272B33.toInt()
        val LINE = 0xFF343942.toInt()
        val TX = 0xFFE8EAEE.toInt()
        val MU = 0xFF9BA3B0.toInt()
        val OK = 0xFF6FC08F.toInt()
        const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    }

    private lateinit var web: WebView
    private lateinit var address: EditText
    private lateinit var shieldBtn: TextView
    private lateinit var progress: ProgressBar
    private lateinit var banner: LinearLayout
    private lateinit var bannerText: TextView
    private lateinit var bannerBtn: TextView
    private lateinit var scrollBar: LinearLayout
    private lateinit var lvlText: TextView
    private lateinit var playBtn: TextView
    private lateinit var backBtn: TextView
    private lateinit var fwdBtn: TextView

    private val prefs by lazy { getSharedPreferences("mb", Context.MODE_PRIVATE) }
    private val main = Handler(Looper.getMainLooper())
    private val hideBanner = Runnable { banner.visibility = View.GONE }

    /** Token rahasia: hanya skrip shield kita yang tahu, jadi skrip situs tidak bisa memakai jembatan. */
    private val token = UUID.randomUUID().toString()
    private var docStart = false
    private var shieldJs = ""

    @Volatile private var shieldOn = true
    @Volatile private var overlayOn = true
    @Volatile private var nextOn = true

    /** Link yang barusan benar-benar diketuk pengguna (dilaporkan skrip shield). */
    @Volatile private var allowKey: String? = null
    @Volatile private var allowAt = 0L
    /** Waktu navigasi sah terakhir, supaya redirect server (3xx) dari navigasi itu tetap lolos. */
    @Volatile private var navOkAt = 0L

    private val netBlocked = AtomicInteger()
    private val jsBlocked = AtomicInteger()
    private var redirBlocked = 0

    private var scrollShown = false
    private var scrolling = false
    private var level = 3

    // ------------------------------------------------------------------ lifecycle

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = SF
        window.navigationBarColor = SF

        shieldOn = prefs.getBoolean("shield", true)
        overlayOn = prefs.getBoolean("overlay", true)
        nextOn = prefs.getBoolean("next", true)
        level = prefs.getInt("lvl", 3).coerceIn(1, 10)

        buildUi()
        setupWeb()

        thread {
            AdBlocker.load(this)
            if (AdBlocker.needsUpdate(this)) try { AdBlocker.update(this) } catch (_: Exception) {}
        }

        val restored = savedInstanceState?.let { web.restoreState(it) } != null
        if (!restored) {
            val data = intent?.data?.toString()
            web.loadUrl(if (data != null && data.startsWith("http")) data else HOME)
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        val data = intent.data?.toString() ?: return
        if (data.startsWith("http")) {
            navOkAt = SystemClock.uptimeMillis()
            web.loadUrl(data)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    override fun onPause() {
        super.onPause()
        web.onPause()
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            banner.visibility == View.VISIBLE -> banner.visibility = View.GONE
            web.canGoBack() -> web.goBack()
            else -> @Suppress("DEPRECATION") super.onBackPressed()
        }
    }

    // ------------------------------------------------------------------ UI

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun round(color: Int, radius: Int, stroke: Int? = null) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        if (stroke != null) setStroke(dp(1), stroke)
    }

    private fun lp(w: Int, h: Int, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
        }

        // --- bilah alamat
        val top = LinearLayout(this).apply {
            setBackgroundColor(SF)
            setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        val pill = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            background = round(SF2, 22, LINE)
            setPadding(dp(4), 0, dp(4), 0)
        }
        shieldBtn = TextView(this).apply {
            text = "🛡"
            textSize = 18f
            gravity = Gravity.CENTER
            setOnClickListener { showSettings() }
        }
        pill.addView(shieldBtn, lp(dp(40), dp(40)))
        address = EditText(this).apply {
            background = null
            setTextColor(TX)
            setHintTextColor(MU)
            hint = "Cari atau ketik alamat"
            textSize = 15f
            isSingleLine = true
            imeOptions = EditorInfo.IME_ACTION_GO
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setSelectAllOnFocus(true)
            setPadding(dp(4), 0, dp(4), 0)
            setOnEditorActionListener { _, id, ev ->
                if (id == EditorInfo.IME_ACTION_GO || ev?.keyCode == KeyEvent.KEYCODE_ENTER) {
                    open(text.toString()); true
                } else false
            }
        }
        pill.addView(address, lp(0, dp(44), 1f))
        val go = TextView(this).apply {
            text = "→"
            textSize = 20f
            setTextColor(MU)
            gravity = Gravity.CENTER
            setOnClickListener { open(address.text.toString()) }
        }
        pill.addView(go, lp(dp(40), dp(40)))
        top.addView(pill, lp(MATCH, WRAP))
        root.addView(top, lp(MATCH, WRAP))

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progressTintList = ColorStateList.valueOf(TX)
            progressBackgroundTintList = ColorStateList.valueOf(SF)
            visibility = View.INVISIBLE
        }
        root.addView(progress, lp(MATCH, dp(3)))

        // --- area halaman
        val frame = FrameLayout(this)
        web = WebView(this)
        frame.addView(web, FrameLayout.LayoutParams(MATCH, MATCH))

        banner = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            background = round(SF, 14, LINE)
            elevation = dp(6).toFloat()
            setPadding(dp(14), dp(8), dp(8), dp(8))
            visibility = View.GONE
        }
        bannerText = TextView(this).apply { setTextColor(TX); textSize = 13.5f }
        banner.addView(bannerText, lp(0, WRAP, 1f))
        bannerBtn = TextView(this).apply {
            setTextColor(BG)
            textSize = 13.5f
            gravity = Gravity.CENTER
            background = round(TX, 14)
            setPadding(dp(14), dp(8), dp(14), dp(8))
        }
        banner.addView(bannerBtn, lp(WRAP, WRAP))
        frame.addView(banner, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP).apply {
            setMargins(dp(10), dp(10), dp(10), 0)
        })

        scrollBar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            background = round(SF, 30, LINE)
            elevation = dp(6).toFloat()
            setPadding(dp(4), dp(4), dp(4), dp(4))
            visibility = View.GONE
        }
        fun roundBtn(t: String, fill: Boolean = false, click: () -> Unit) = TextView(this).apply {
            text = t
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(if (fill) BG else TX)
            if (fill) background = round(TX, 23)
            setOnClickListener { click() }
        }
        scrollBar.addView(roundBtn("−") { setLevel(level - 1) }, lp(dp(46), dp(46)))
        lvlText = TextView(this).apply { setTextColor(TX); textSize = 17f; gravity = Gravity.CENTER }
        scrollBar.addView(lvlText, lp(dp(56), dp(46)))
        scrollBar.addView(roundBtn("+") { setLevel(level + 1) }, lp(dp(46), dp(46)))
        playBtn = roundBtn("▶", true) { scrolling = !scrolling; applyScroll() }
        scrollBar.addView(playBtn, lp(dp(46), dp(46)))
        frame.addView(scrollBar, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
            bottomMargin = dp(14)
        })
        root.addView(frame, lp(MATCH, 0, 1f))

        // --- dock bawah
        val dock = LinearLayout(this).apply {
            setBackgroundColor(SF)
            setPadding(dp(6), 0, dp(6), 0)
        }
        fun dockBtn(icon: String, label: String, click: () -> Unit) = TextView(this).apply {
            val s = SpannableString("$icon\n$label")
            s.setSpan(RelativeSizeSpan(1.9f), 0, icon.length, 0)
            text = s
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(MU)
            setLineSpacing(0f, 0.9f)
            setOnClickListener { click() }
        }.also { dock.addView(it, lp(0, dp(58), 1f)) }
        backBtn = dockBtn("‹", "Kembali") { if (web.canGoBack()) web.goBack() }
        fwdBtn = dockBtn("›", "Maju") { if (web.canGoForward()) web.goForward() }
        dockBtn("↻", "Segarkan") { web.reload() }
        dockBtn("⌂", "Beranda") { web.loadUrl(HOME) }
        dockBtn("↓", "Gulir") { toggleScroll() }
        dockBtn("≡", "Menu") { showSettings() }
        root.addView(dock, lp(MATCH, WRAP))

        setContentView(root)
        updateShield()
        applyScroll()
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    private fun showBanner(text: String, label: String? = null, ms: Long = 5000, action: (() -> Unit)? = null) {
        bannerText.text = text
        if (label != null && action != null) {
            bannerBtn.text = label
            bannerBtn.visibility = View.VISIBLE
            bannerBtn.setOnClickListener { banner.visibility = View.GONE; action() }
        } else bannerBtn.visibility = View.GONE
        banner.visibility = View.VISIBLE
        main.removeCallbacks(hideBanner)
        main.postDelayed(hideBanner, ms)
    }

    private fun updateShield() {
        shieldBtn.alpha = if (shieldOn) 1f else 0.35f
    }

    private fun updateNav() {
        backBtn.alpha = if (web.canGoBack()) 1f else 0.35f
        fwdBtn.alpha = if (web.canGoForward()) 1f else 0.35f
    }

    private fun showAddress(url: String?) {
        if (address.hasFocus()) return
        address.setText(if (url == null || url.startsWith("file:")) "" else url)
    }

    private fun showSettings() {
        val items = arrayOf(
            "Shield: blokir iklan, popup & redirect",
            "Hapus overlay promo",
            "Chapter berikutnya otomatis"
        )
        val checked = booleanArrayOf(shieldOn, overlayOn, nextOn)
        val total = netBlocked.get() + jsBlocked.get()
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Diblokir: $total iklan · $redirBlocked redirect")
            .setMultiChoiceItems(items, checked) { _, i, v -> checked[i] = v }
            .setNeutralButton("Perbarui daftar iklan") { _, _ -> updateList() }
            .setPositiveButton("Selesai") { _, _ ->
                val changed = checked[0] != shieldOn || checked[1] != overlayOn || checked[2] != nextOn
                shieldOn = checked[0]; overlayOn = checked[1]; nextOn = checked[2]
                prefs.edit()
                    .putBoolean("shield", shieldOn)
                    .putBoolean("overlay", overlayOn)
                    .putBoolean("next", nextOn)
                    .apply()
                updateShield()
                if (changed) web.reload()
            }
            .show()
    }

    private fun updateList() {
        toast("Mengunduh daftar iklan…")
        thread {
            val n = try { AdBlocker.update(this) } catch (_: Exception) { -1 }
            main.post { toast(if (n > 0) "Daftar iklan diperbarui: $n domain" else "Gagal memperbarui daftar") }
        }
    }

    private fun normalize(v0: String): String {
        val v = v0.trim()
        if (v.isEmpty()) return ""
        if (Regex("^https?://", RegexOption.IGNORE_CASE).containsMatchIn(v)) return v
        if (Regex("^[a-z0-9.-]+\\.[a-z]{2,}(/.*)?$", RegexOption.IGNORE_CASE).matches(v)) return "https://$v"
        return "https://www.google.com/search?q=" + Uri.encode(v)
    }

    private fun open(v: String) {
        val u = normalize(v)
        if (u.isEmpty()) return
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(address.windowToken, 0)
        address.clearFocus()
        navOkAt = SystemClock.uptimeMillis()
        web.loadUrl(u)
    }

    // ------------------------------------------------------------------ auto-scroll

    private fun toggleScroll() {
        val u = web.url
        if (u == null || u.startsWith("file:")) { toast("Buka halaman dulu"); return }
        scrollShown = !scrollShown
        scrolling = scrollShown
        applyScroll()
    }

    private fun setLevel(l: Int) {
        level = l.coerceIn(1, 10)
        prefs.edit().putInt("lvl", level).apply()
        applyScroll()
    }

    private fun applyScroll() {
        scrollBar.visibility = if (scrollShown) View.VISIBLE else View.GONE
        lvlText.text = level.toString()
        playBtn.text = if (scrolling) "❚❚" else "▶"
        val v = if (scrolling && scrollShown) SPEEDS[level - 1] else 0
        if (::web.isInitialized) web.evaluateJavascript("window.__mbScroll&&window.__mbScroll($v)", null)
        if (v > 0) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    // ------------------------------------------------------------------ redirect

    /** host + path tanpa query/fragmen dan garis miring akhir, untuk mencocokkan link yang diketuk. */
    private fun key(url: String): String {
        val u = Uri.parse(url)
        return (u.host ?: "").lowercase().removePrefix("www.") + (u.path ?: "").trimEnd('/')
    }

    private fun sameSite(a: String?, b: String?) = AdBlocker.reg(a) == AdBlocker.reg(b)

    private fun blockRedirect(url: String, canOpen: Boolean) {
        redirBlocked++
        val host = Uri.parse(url).host ?: url.take(40)
        if (canOpen) showBanner("Redirect diblokir: $host", "Buka tetap") {
            navOkAt = SystemClock.uptimeMillis()
            web.loadUrl(url)
        } else showBanner("Iklan diblokir: $host")
    }

    // ------------------------------------------------------------------ WebView

    @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
    private fun setupWeb() {
        shieldJs = assets.open("shield.js").bufferedReader().use { it.readText() }.replace("__MB_TOKEN__", token)

        web.setBackgroundColor(BG)
        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            loadWithOverviewMode = true
            useWideViewPort = true
            builtInZoomControls = true
            displayZoomControls = false
            mediaPlaybackRequiresUserGesture = true
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(true)
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        }
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, false)

        web.addJavascriptInterface(Bridge(), "MBNative")

        // Skrip shield dijalankan SEBELUM skrip situs (kalau WebView mendukung)
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            WebViewCompat.addDocumentStartJavaScript(web, shieldJs, setOf("*"))
            docStart = true
        }

        web.webViewClient = object : WebViewClient() {

            override fun shouldInterceptRequest(view: WebView, req: WebResourceRequest): WebResourceResponse? {
                if (!shieldOn || req.isForMainFrame) return null
                val url = req.url.toString()
                if (!url.startsWith("http")) return null
                if (AdBlocker.isBlocked(url)) {
                    netBlocked.incrementAndGet()
                    // balas "sukses kosong" supaya skrip deteksi adblock tidak curiga
                    return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                }
                return null
            }

            override fun shouldOverrideUrlLoading(view: WebView, req: WebResourceRequest): Boolean {
                val url = req.url.toString()
                val scheme = req.url.scheme?.lowercase() ?: ""

                if (!req.isForMainFrame) {
                    return shieldOn && AdBlocker.isBlocked(url)
                }

                // intent://, market://, tg:// dll. Iklan suka melempar ke Play Store
                if (scheme != "http" && scheme != "https") {
                    if (scheme == "about" || scheme == "javascript" || scheme == "file" || scheme == "blob" || scheme == "data") return false
                    if (shieldOn && !req.hasGesture()) { blockRedirect(url, false); return true }
                    showBanner("Buka di aplikasi lain?", "Buka", 6000) {
                        try {
                            val i = if (scheme == "intent") Intent.parseUri(url, Intent.URI_INTENT_SCHEME) else Intent(Intent.ACTION_VIEW, req.url)
                            i.addCategory(Intent.CATEGORY_BROWSABLE)
                            i.component = null
                            i.selector = null
                            startActivity(i)
                        } catch (_: Exception) { toast("Tidak ada aplikasi untuk membuka link ini") }
                    }
                    return true
                }

                if (!shieldOn) return false

                val host = req.url.host
                if (AdBlocker.isBlocked(url)) { blockRedirect(url, false); return true }

                val cur = view.url
                val now = SystemClock.uptimeMillis()
                // dari beranda, atau masih di situs yang sama: aman
                if (cur == null || cur.startsWith("file:") || cur == "about:blank") { navOkAt = now; return false }
                if (sameSite(host, Uri.parse(cur).host)) { navOkAt = now; return false }
                // redirect server (3xx) dari navigasi yang sudah disetujui
                if (req.isRedirect && now - navOkAt < 8000) { navOkAt = now; return false }
                // link lintas situs yang benar-benar diketuk pengguna
                val k = allowKey
                if (req.hasGesture() && k != null && now - allowAt < 4000 && k == key(url)) {
                    allowKey = null; navOkAt = now; return false
                }
                // selain itu: skrip mencoba memindahkan halaman ke situs lain = redirect iklan
                blockRedirect(url, true)
                return true
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                showAddress(url)
                progress.visibility = View.VISIBLE
                if (scrolling) { scrolling = false; applyScroll() }
                updateNav()
            }

            override fun onPageCommitVisible(view: WebView, url: String?) {
                if (!docStart) view.evaluateJavascript(shieldJs, null)
            }

            override fun onPageFinished(view: WebView, url: String?) {
                progress.visibility = View.INVISIBLE
                if (!docStart) view.evaluateJavascript(shieldJs, null)
                updateNav()
            }

            override fun doUpdateVisitedHistory(view: WebView, url: String?, isReload: Boolean) {
                showAddress(url)
                updateNav()
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, p: Int) {
                progress.progress = p
            }

            override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message): Boolean {
                if (shieldOn) {
                    // popup & popunder diblokir total; link target=_blank sudah dialihkan oleh skrip shield
                    jsBlocked.incrementAndGet()
                    return false
                }
                // Shield mati: buka popup di tab yang sama
                val tmp = WebView(this@MainActivity)
                tmp.webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                        web.loadUrl(r.url.toString())
                        v.destroy()
                        return true
                    }
                }
                (resultMsg.obj as WebView.WebViewTransport).webView = tmp
                resultMsg.sendToTarget()
                return true
            }
        }

        web.setDownloadListener { url, ua, cd, mime, _ ->
            val name = URLUtil.guessFileName(url, cd, mime)
            showBanner("Unduh $name?", "Unduh", 8000) {
                try {
                    val r = DownloadManager.Request(Uri.parse(url)).apply {
                        setMimeType(mime)
                        addRequestHeader("User-Agent", ua)
                        CookieManager.getInstance().getCookie(url)?.let { addRequestHeader("Cookie", it) }
                        setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                        setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
                    }
                    (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(r)
                    toast("Mengunduh $name")
                } catch (_: Exception) {
                    toast("Gagal mengunduh")
                }
            }
        }
    }

    /** Jembatan untuk skrip shield. Setiap panggilan wajib membawa token. */
    inner class Bridge {
        @JavascriptInterface
        fun cfg(t: String): String =
            if (t != token) "{}"
            else JSONObject().put("on", shieldOn).put("o", overlayOn).put("n", nextOn).toString()

        @JavascriptInterface
        fun allow(t: String, u: String) {
            if (t != token) return
            allowKey = key(u)
            allowAt = SystemClock.uptimeMillis()
        }

        @JavascriptInterface
        fun add(t: String, n: Int) {
            if (t == token && n > 0) jsBlocked.addAndGet(n)
        }

        @JavascriptInterface
        fun redir(t: String, u: String) {
            if (t == token) main.post { blockRedirect(u, true) }
        }

        @JavascriptInterface
        fun cur(t: String, u: String) {
            if (t == token) main.post { showAddress(u) }
        }

        @JavascriptInterface
        fun scroll(t: String, s: String) {
            if (t != token) return
            main.post {
                scrolling = false
                applyScroll()
                if (s == "end") toast("Sampai di akhir halaman")
            }
        }

        @JavascriptInterface
        fun msg(t: String, m: String) {
            if (t == token) main.post { toast(m.take(120)) }
        }
    }
}
