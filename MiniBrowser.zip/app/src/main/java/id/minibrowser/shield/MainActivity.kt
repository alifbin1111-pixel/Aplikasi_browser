package id.minibrowser.shield

import android.annotation.SuppressLint
import android.app.Activity
import android.app.Dialog
import android.app.DownloadManager
import android.content.Context
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentCallbacks2
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.ConnectivityManager
import android.net.TrafficStats
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.os.SystemClock
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.RenderProcessGoneDetail
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.webkit.ProxyConfig
import androidx.webkit.ProxyController
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.util.UUID
import java.util.concurrent.atomic.AtomicInteger
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private companion object {
        const val HOME = "file:///android_asset/home.html"
        val SPEEDS = intArrayOf(12, 20, 30, 45, 65, 90, 125, 170, 230, 300)
        const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    }

    private lateinit var web: WebView
    private lateinit var address: EditText
    private lateinit var shieldIcon: ImageView
    private lateinit var progress: ProgressBar
    private lateinit var banner: LinearLayout
    private lateinit var bannerText: TextView
    private lateinit var bannerBtn: TextView
    private lateinit var scrollBar: LinearLayout
    private lateinit var lvlText: TextView
    private lateinit var playIcon: ImageView
    private var backBtn: View? = null
    /** Dock melayang (tema Samudra, Mint, Sakura): disembunyikan saat menggulir ke bawah. */
    private var floatDock: View? = null
    private var dockHidden = false
    private var fwdBtn: View? = null

    private val prefs by lazy { getSharedPreferences("mb", Context.MODE_PRIVATE) }
    private val main = Handler(Looper.getMainLooper())
    private val hideBanner = Runnable { fadeOut(banner) }

    private var t: Theme = Themes.all[0]

    /** Token rahasia: hanya skrip shield kita yang tahu, jadi skrip situs tidak bisa memakai jembatan. */
    private val token = UUID.randomUUID().toString()
    private var docStart = false
    private var shieldJs = ""

    @Volatile private var shieldOn = true
    @Volatile private var overlayOn = true
    @Volatile private var nextOn = true
    @Volatile private var saverOn = true
    @Volatile private var engine = "google"
    @Volatile private var region = "SG"
    @Volatile private var safeSearch = false
    private var dnsId = "cloudflare"

    @Volatile private var allowKey: String? = null
    @Volatile private var allowAt = 0L
    @Volatile private var navOkAt = 0L

    private val netBlocked = AtomicInteger()
    private val jsBlocked = AtomicInteger()
    private var redirBlocked = 0

    private var scrollShown = false
    private var scrolling = false
    private var level = 3
    private var currentUrl: String? = null
    private var destroyed = false

    // pemakaian data aplikasi ini (TrafficStats per UID), dipisah dipakai vs latar belakang
    private val uid = android.os.Process.myUid()
    private var sessionStart = -1L
    private var bgStart = -1L
    private var bgBytes = 0L
    private val stopInBackground = Runnable { if (!destroyed) web.stopLoading() }
    private var lastGoneAt = 0L

    // ================================================================== lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        shieldOn = prefs.getBoolean("shield", true)
        overlayOn = prefs.getBoolean("overlay", true)
        nextOn = prefs.getBoolean("next", true)
        saverOn = prefs.getBoolean("saver", true)
        level = prefs.getInt("lvl", 3).coerceIn(1, 10)
        engine = prefs.getString("engine", "google") ?: "google"
        region = prefs.getString("region", "SG") ?: "SG"
        safeSearch = prefs.getBoolean("safe", false)
        dnsId = prefs.getString("dns", "cloudflare") ?: "cloudflare"
        t = Themes.byId(prefs.getString("theme", null))

        web = WebView(this)
        setupWeb()
        buildUi()

        thread(name = "mb-adlist") {
            try {
                AdBlocker.load(this)
                val now = System.currentTimeMillis()
                // pembaruan otomatis hanya lewat Wi-Fi/tanpa kuota, dan paling sering sekali sehari
                if (AdBlocker.needsUpdate(this) && !isMetered() && now - prefs.getLong("listTry", 0) > 86_400_000L) {
                    prefs.edit().putLong("listTry", now).apply()
                    AdBlocker.update(this)
                }
            } catch (_: Throwable) {}
        }

        // Hanya alamat terakhir yang disimpan. Menyimpan seluruh riwayat WebView ke Bundle
        // bisa melebihi batas 1 MB dan membuat aplikasi tertutup saat dipindah ke latar.
        val savedUrl = savedInstanceState?.getString("url")
        applyDns {
            if (destroyed) return@applyDns
            val data = intent?.data?.toString()
            web.loadUrl(when {
                data != null && data.startsWith("http") -> data
                savedUrl != null && savedUrl.startsWith("http") -> savedUrl
                else -> HOME
            })
        }
        showCrashReport()
    }

    /** Kalau sesi sebelumnya tertutup karena error, tawarkan menyalin laporannya. */
    private fun showCrashReport() {
        val f = java.io.File(filesDir, "crash.txt")
        if (!f.exists()) return
        val report = try { f.readText() } catch (_: Throwable) { "" }
        f.delete()
        if (report.isEmpty()) return
        main.postDelayed({
            if (destroyed) return@postDelayed
            showBanner("MiniBrowser sempat tertutup. Salin laporan error?", "Salin", 12000) {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("Laporan MiniBrowser", report))
                toast("Laporan disalin, kirimkan ke pengembang")
            }
        }, 800)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        val data = intent.data?.toString() ?: return
        if (data.startsWith("http")) {
            navOkAt = SystemClock.uptimeMillis()
            web.loadUrl(data)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        (currentUrl ?: web.url)?.let { if (it.startsWith("http")) outState.putString("url", it) }
    }

    private fun appBytes(): Long {
        val rx = TrafficStats.getUidRxBytes(uid)
        val tx = TrafficStats.getUidTxBytes(uid)
        return if (rx < 0 || tx < 0) -1L else rx + tx
    }

    private fun isMetered(): Boolean = try {
        (getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager).isActiveNetworkMetered
    } catch (_: Throwable) { true }

    private fun mb(b: Long) = if (b < 1_048_576L) String.format("%.1f MB", b / 1_048_576.0) else String.format("%.0f MB", b / 1_048_576.0)

    override fun onStart() {
        super.onStart()
        SecureDns.setBackground(false)
        main.removeCallbacks(stopInBackground)
        val now = appBytes()
        if (sessionStart < 0) sessionStart = now
        if (bgStart >= 0 && now >= bgStart) bgBytes += now - bgStart
        bgStart = -1
    }

    /**
     * Aplikasi tidak terlihat: setelah 15 detik semua pemuatan dihentikan dan proxy
     * memutus aliran data, jadi tidak ada kuota terpakai di latar belakang.
     */
    override fun onStop() {
        super.onStop()
        bgStart = appBytes()
        SecureDns.setBackground(true)
        main.postDelayed(stopInBackground, 15_000L)
    }

    /** Di latar belakang semua timer JavaScript dihentikan: hemat baterai, HP tidak panas. */
    override fun onPause() {
        super.onPause()
        if (scrolling) { scrolling = false; applyScroll() }
        web.onPause()
        web.pauseTimers()
    }

    override fun onResume() {
        super.onResume()
        web.resumeTimers()
        web.onResume()
    }

    /** Saat memori HP menipis: lepaskan cache yang bisa dibuat ulang. */
    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW) SecureDns.trim()
    }

    override fun onDestroy() {
        destroyed = true
        main.removeCallbacksAndMessages(null)
        web.destroy()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            address.hasFocus() -> { hideKeyboard(); address.clearFocus() }
            banner.visibility == View.VISIBLE -> fadeOut(banner)
            web.canGoBack() -> web.goBack()
            else -> @Suppress("DEPRECATION") super.onBackPressed()
        }
    }

    // ================================================================== helpers

    private fun dp(v: Float) = (v * resources.displayMetrics.density).toInt()
    private fun dp(v: Int) = dp(v.toFloat())
    private fun sz(v: Int) = dp(v * t.scale)
    private fun r(v: Int) = dp(minOf(v, t.radius))
    private fun lp(w: Int, h: Int, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)

    private fun shape(color: Int, radius: Int, stroke: Int? = null, strokeW: Int = 1) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius.toFloat()
        if (stroke != null) setStroke(dp(strokeW), stroke)
    }

    /** Efek sentuh (ripple) dengan warna sesuai tema. */
    private fun ripple(content: Drawable?, radius: Int): Drawable =
        RippleDrawable(ColorStateList.valueOf(withAlpha(t.text, 0x22)), content, shape(Color.WHITE, radius))

    private fun withAlpha(c: Int, a: Int) = (c and 0x00FFFFFF) or (a shl 24)

    private fun text(s: String, size: Float, color: Int = t.text, bold: Boolean = false) = TextView(this).apply {
        text = s
        textSize = size * t.scale
        setTextColor(color)
        typeface = t.font.typeface(bold)
    }

    private fun icon(res: Int, color: Int, size: Int = 22) = ImageView(this).apply {
        setImageResource(res)
        imageTintList = ColorStateList.valueOf(color)
        scaleType = ImageView.ScaleType.FIT_CENTER
        layoutParams = lp(sz(size), sz(size))
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun hideKeyboard() {
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(address.windowToken, 0)
    }

    private fun fadeIn(v: View) {
        if (v.visibility == View.VISIBLE) return
        v.alpha = 0f; v.translationY = -dp(8).toFloat(); v.visibility = View.VISIBLE
        v.animate().alpha(1f).translationY(0f).setDuration(180).start()
    }

    private fun fadeOut(v: View) {
        if (v.visibility != View.VISIBLE) return
        v.animate().alpha(0f).setDuration(150).withEndAction { v.visibility = View.GONE }.start()
    }

    // ================================================================== UI

    @Suppress("DEPRECATION")
    private fun applySystemBars() {
        window.setBackgroundDrawable(ColorDrawable(t.bg))
        window.statusBarColor = if (t.addrBottom) t.bg else t.surface
        window.navigationBarColor = if (t.dock == Dock.FLOAT && !t.addrBottom) t.bg else t.surface
        var flags = 0
        if (!t.dark) {
            flags = flags or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            if (Build.VERSION.SDK_INT >= 26) flags = flags or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }
        window.decorView.systemUiVisibility = flags
    }

    /** Membangun ulang seluruh tampilan sesuai tema. WebView dipindahkan, bukan dibuat ulang. */
    private fun buildUi() {
        (web.parent as? ViewGroup)?.removeView(web)
        applySystemBars()
        web.setBackgroundColor(t.bg)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(t.bg)
        }

        val addrBar = buildAddressBar()
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progressTintList = ColorStateList.valueOf(t.accent)
            progressBackgroundTintList = ColorStateList.valueOf(Color.TRANSPARENT)
            visibility = View.INVISIBLE
        }

        if (!t.addrBottom) {
            root.addView(addrBar, lp(MATCH, WRAP))
            root.addView(progress, lp(MATCH, dp(2)))
        }

        val frame = FrameLayout(this)
        frame.addView(web, FrameLayout.LayoutParams(MATCH, MATCH))
        buildBanner(frame)
        val isFloat = t.dock == Dock.FLOAT
        buildScrollBar(frame, if (isFloat) 84 else 16)
        floatDock = null
        dockHidden = false
        if (isFloat) {
            val dock = buildDock(true)
            frame.addView(dock, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM).apply {
                setMargins(dp(16), 0, dp(16), dp(14))
            })
            floatDock = dock
        }
        root.addView(frame, lp(MATCH, 0, 1f))

        if (t.addrBottom) {
            root.addView(progress, lp(MATCH, dp(2)))
            root.addView(addrBar, lp(MATCH, WRAP))
        }
        if (!isFloat) root.addView(buildDock(false), lp(MATCH, WRAP))

        setContentView(root)
        showAddress(web.url)
        updateShield()
        updateNav()
        applyScroll()
    }

    private fun buildAddressBar(): View {
        val bar = LinearLayout(this).apply {
            setBackgroundColor(t.surface)
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), sz(8), dp(12), sz(8))
        }
        val pill = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            background = shape(t.surface2, r(26), t.line)
            setPadding(dp(4), 0, dp(4), 0)
        }
        shieldIcon = icon(R.drawable.ic_shield_check, t.accent, 20)
        val shieldWrap = FrameLayout(this).apply {
            background = ripple(null, dp(20))
            isClickable = true
            setOnClickListener { showSettings() }
            contentDescription = "Status Shield"
            addView(shieldIcon, FrameLayout.LayoutParams(sz(20), sz(20), Gravity.CENTER))
        }
        pill.addView(shieldWrap, lp(sz(40), sz(40)))

        address = EditText(this).apply {
            background = null
            setTextColor(t.text)
            setHintTextColor(t.muted)
            hint = "Cari atau ketik alamat"
            textSize = 15f * t.scale
            typeface = t.font.typeface()
            isSingleLine = true
            ellipsize = TextUtils.TruncateAt.END
            imeOptions = EditorInfo.IME_ACTION_GO
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setPadding(dp(2), 0, dp(2), 0)
            if (Build.VERSION.SDK_INT >= 29) setTextCursorDrawable(shape(t.accent, 0).apply { setSize(dp(2), dp(18)) })
            highlightColor = withAlpha(t.accent, 0x55)
            setOnEditorActionListener { _, id, ev ->
                if (id == EditorInfo.IME_ACTION_GO || ev?.keyCode == KeyEvent.KEYCODE_ENTER) {
                    open(text.toString()); true
                } else false
            }
            setOnFocusChangeListener { _, has ->
                showDock(!has)
                if (has) {
                    val u = currentUrl
                    setText(if (u == null || u.startsWith("file:")) "" else u)
                    post { selectAll() }
                } else showAddress(currentUrl)
            }
        }
        pill.addView(address, lp(0, sz(44), 1f))

        val go = FrameLayout(this).apply {
            background = ripple(null, dp(20))
            isClickable = true
            setOnClickListener { open(address.text.toString()) }
            contentDescription = "Buka"
            addView(icon(R.drawable.ic_go, t.muted, 20), FrameLayout.LayoutParams(sz(20), sz(20), Gravity.CENTER))
        }
        pill.addView(go, lp(sz(40), sz(40)))
        bar.addView(pill, lp(MATCH, WRAP))

        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val divider = View(this).apply { setBackgroundColor(t.line) }
        if (t.addrBottom) wrap.addView(divider, lp(MATCH, 1))
        wrap.addView(bar, lp(MATCH, WRAP))
        if (!t.addrBottom) wrap.addView(divider, lp(MATCH, 1))
        return wrap
    }

    private fun buildDock(floating: Boolean): View {
        val labels = !floating && t.dock == Dock.LABELS
        val dock = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            if (floating) {
                background = shape(t.surface, r(28), t.line)
                elevation = dp(8).toFloat()
                setPadding(dp(6), dp(4), dp(6), dp(4))
            } else {
                setBackgroundColor(t.surface)
                setPadding(dp(6), 0, dp(6), 0)
            }
        }
        fun item(res: Int, label: String, click: () -> Unit): View {
            val v = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                background = ripple(null, r(16))
                isClickable = true
                contentDescription = label
                setOnClickListener { click() }
                addView(icon(res, t.muted, 22))
                if (labels) {
                    val tv = text(if (t.upper) label.uppercase() else label, 11f, t.muted, t.boldLabels).apply {
                        maxLines = 1
                        ellipsize = TextUtils.TruncateAt.END
                        gravity = Gravity.CENTER
                    }
                    tv.setPadding(0, dp(3), 0, 0)
                    addView(tv)
                }
            }
            val h = when {
                floating -> sz(48)
                labels -> sz(60)
                else -> sz(54)
            }
            dock.addView(v, lp(0, h, 1f).apply { if (floating) setMargins(dp(2), 0, dp(2), 0) })
            return v
        }
        backBtn = item(R.drawable.ic_back, "Kembali") { if (web.canGoBack()) web.goBack() }
        fwdBtn = item(R.drawable.ic_forward, "Maju") { if (web.canGoForward()) web.goForward() }
        item(R.drawable.ic_reload, "Segarkan") { web.reload() }
        item(R.drawable.ic_home, "Beranda") { web.loadUrl(HOME) }
        item(R.drawable.ic_scroll, "Gulir") { toggleScroll() }
        item(R.drawable.ic_menu, "Menu") { showSettings() }

        if (floating) return dock
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        wrap.addView(View(this).apply { setBackgroundColor(t.line) }, lp(MATCH, 1))
        wrap.addView(dock, lp(MATCH, WRAP))
        return wrap
    }

    private fun buildBanner(frame: FrameLayout) {
        banner = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            background = shape(t.surface, r(16), t.line)
            elevation = dp(8).toFloat()
            setPadding(dp(14), dp(10), dp(8), dp(10))
            visibility = View.GONE
        }
        banner.addView(icon(R.drawable.ic_shield_check, t.accent, 20).apply {
            (layoutParams as LinearLayout.LayoutParams).marginEnd = dp(10)
        })
        bannerText = text("", 13.5f)
        banner.addView(bannerText, lp(0, WRAP, 1f))
        bannerBtn = text("", 13.5f, t.onAccent, true).apply {
            gravity = Gravity.CENTER
            background = ripple(shape(t.accent, r(14)), r(14))
            setPadding(dp(14), dp(8), dp(14), dp(8))
        }
        banner.addView(bannerBtn, lp(WRAP, WRAP).apply { marginStart = dp(8) })
        val g = if (t.addrBottom) Gravity.BOTTOM else Gravity.TOP
        frame.addView(banner, FrameLayout.LayoutParams(MATCH, WRAP, g).apply {
            setMargins(dp(12), dp(12), dp(12), dp(if (t.dock == Dock.FLOAT) 84 else 12))
        })
    }

    private fun buildScrollBar(frame: FrameLayout, bottom: Int) {
        scrollBar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            background = shape(t.surface, r(30), t.line)
            elevation = dp(8).toFloat()
            setPadding(dp(4), dp(4), dp(4), dp(4))
            visibility = View.GONE
        }
        fun btn(res: Int, fill: Boolean, click: () -> Unit): ImageView {
            val ic = icon(res, if (fill) t.onAccent else t.text, 20)
            val f = FrameLayout(this).apply {
                background = ripple(if (fill) shape(t.accent, r(23)) else null, r(23))
                isClickable = true
                setOnClickListener { click() }
                addView(ic, FrameLayout.LayoutParams(sz(20), sz(20), Gravity.CENTER))
            }
            scrollBar.addView(f, lp(sz(46), sz(46)))
            return ic
        }
        btn(R.drawable.ic_minus, false) { setLevel(level - 1) }
        val lv = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        lv.addView(text("Kecepatan", 10f, t.muted).apply { gravity = Gravity.CENTER })
        lvlText = text("3", 17f, t.text, true).apply { gravity = Gravity.CENTER }
        lv.addView(lvlText)
        scrollBar.addView(lv, lp(sz(70), sz(46)))
        btn(R.drawable.ic_plus, false) { setLevel(level + 1) }
        playIcon = btn(R.drawable.ic_play, true) { scrolling = !scrolling; applyScroll() }
        frame.addView(scrollBar, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
            bottomMargin = dp(bottom)
        })
    }

    private fun showBanner(msg: String, label: String? = null, ms: Long = 5000, action: (() -> Unit)? = null) {
        bannerText.text = msg
        if (label != null && action != null) {
            bannerBtn.text = if (t.upper) label.uppercase() else label
            bannerBtn.visibility = View.VISIBLE
            bannerBtn.setOnClickListener { fadeOut(banner); action() }
        } else bannerBtn.visibility = View.GONE
        fadeIn(banner)
        main.removeCallbacks(hideBanner)
        main.postDelayed(hideBanner, ms)
    }

    private fun showDock(show: Boolean) {
        val v = floatDock ?: return
        if (show == !dockHidden) return
        dockHidden = !show
        v.animate().cancel()
        if (show) {
            v.visibility = View.VISIBLE
            v.animate().translationY(0f).alpha(1f).setDuration(160).start()
        } else {
            v.animate().translationY((v.height + dp(20)).toFloat()).alpha(0f).setDuration(160)
                .withEndAction { if (dockHidden) v.visibility = View.INVISIBLE }.start()
        }
    }

    private fun updateShield() {
        shieldIcon.setImageResource(if (shieldOn) R.drawable.ic_shield_check else R.drawable.ic_shield)
        shieldIcon.imageTintList = ColorStateList.valueOf(if (shieldOn) t.accent else t.muted)
    }

    private fun updateNav() {
        backBtn?.alpha = if (web.canGoBack()) 1f else 0.35f
        fwdBtn?.alpha = if (web.canGoForward()) 1f else 0.35f
    }

    /** Saat tidak diketik, bilah alamat menampilkan domain atau kata kunci pencarian saja. */
    private fun showAddress(url: String?) {
        currentUrl = url
        if (!::address.isInitialized || address.hasFocus()) return
        val shown = when {
            url == null || url.startsWith("file:") || url == "about:blank" -> ""
            else -> Search.queryOf(url) ?: (Uri.parse(url).host?.removePrefix("www.") ?: url)
        }
        address.setText(shown)
    }

    // ================================================================== DNS aman

    private fun dnsSupported() = WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)

    /** Mengarahkan WebView ke proxy DoH lokal (atau melepasnya untuk DNS sistem). */
    private fun applyDns(then: () -> Unit) {
        val p = SecureDns.byId(dnsId)
        SecureDns.select(p)
        if (!dnsSupported()) {
            if (p.url != null) main.post { toast("DNS aman butuh Android System WebView terbaru") }
            then(); return
        }
        val done = Runnable { main.post(then) }
        try {
            if (p.url == null) {
                ProxyController.getInstance().clearProxyOverride({ it.run() }, done)
            } else {
                val port = SecureDns.startProxy()
                val cfg = ProxyConfig.Builder().addProxyRule("127.0.0.1:$port").build()
                ProxyController.getInstance().setProxyOverride(cfg, { it.run() }, done)
            }
        } catch (e: Exception) {
            toast("Gagal memasang DNS aman")
            then()
        }
    }

    private fun pickDns(onPicked: () -> Unit) {
        val list = SecureDns.providers
        val cur = list.indexOfFirst { it.id == dnsId }.coerceAtLeast(0)
        pickSheet("DNS aman", "Pencarian alamat lewat jalur terenkripsi (DNS-over-HTTPS)",
            list.map { it.name to it.desc }, cur) { i ->
            dnsId = list[i].id
            prefs.edit().putString("dns", dnsId).apply()
            applyDns {
                web.reload()
                toast("DNS: " + list[i].name)
            }
            onPicked()
        }
    }

    /** Pilihan tunggal dalam lembar bawah bertema (pengganti AlertDialog bawaan yang tidak ikut tema). */
    private fun pickSheet(title: String, sub: String?, items: List<Pair<String, String?>>, selected: Int, onPick: (Int) -> Unit) {
        if (isFinishing || destroyed) return
        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val box = sheetBox()
        box.addView(text(title, 18f, t.text, true))
        if (sub != null) box.addView(text(sub, 12.5f, t.muted), lp(MATCH, WRAP).apply { topMargin = dp(2) })
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        items.forEachIndexed { i, (name, desc) ->
            val on = i == selected
            val rowV = LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(14), dp(12), dp(14), dp(12))
                background = ripple(if (on) shape(t.surface2, r(14), t.accent) else null, r(14))
                isClickable = true
                setOnClickListener { d.dismiss(); if (!on) onPick(i) }
            }
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            col.addView(text(name, 15f, t.text, on))
            if (desc != null) col.addView(text(desc, 12.5f, t.muted))
            rowV.addView(col, lp(0, WRAP, 1f))
            val mark = if (on) icon(R.drawable.ic_check, t.accent, 20)
            else View(this).apply { background = shape(Color.TRANSPARENT, dp(10), t.line, 2); layoutParams = lp(sz(20), sz(20)) }
            rowV.addView(mark)
            list.addView(rowV, lp(MATCH, WRAP).apply { topMargin = dp(4) })
        }
        box.addView(list, lp(MATCH, WRAP).apply { topMargin = dp(12) })
        showSheet(d, box)
    }

    /** Wadah lembar bawah: sudut atas membulat + pegangan. */
    private fun sheetBox() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = GradientDrawable().apply {
            setColor(t.surface)
            val rr = r(24).toFloat()
            cornerRadii = floatArrayOf(rr, rr, rr, rr, 0f, 0f, 0f, 0f)
        }
        setPadding(dp(20), dp(10), dp(20), dp(24))
        addView(View(this@MainActivity).apply { background = shape(t.line, dp(2)) },
            lp(dp(40), dp(4)).apply { gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = dp(16) })
    }

    /** Menampilkan lembar: tinggi mengikuti isi (maks 88% layar), tanpa lompatan ukuran. */
    private fun showSheet(d: Dialog, box: View): ScrollView {
        val maxH = (resources.displayMetrics.heightPixels * 0.88f).toInt()
        val scroll = MaxHeightScrollView(this, maxH).apply {
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            isFillViewport = true
            addView(box)
        }
        d.setContentView(scroll)
        d.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setLayout(MATCH, WRAP)
            setGravity(Gravity.BOTTOM)
            setWindowAnimations(android.R.style.Animation_InputMethod)
            setDimAmount(0.45f)
            if (Build.VERSION.SDK_INT >= 27) navigationBarColor = t.surface
        }
        d.show()
        return scroll
    }

    // ================================================================== settings sheet

    private fun showSettings(scrollToThemes: Boolean = false) {
        if (isFinishing || destroyed) return
        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        var reload = false
        var reopenThemes = false

        val sheet = sheetBox()

        // judul + logo
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(ImageView(this).apply { setImageResource(R.mipmap.ic_launcher) }, lp(dp(40), dp(40)))
        val ht = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        ht.addView(text("MiniBrowser", 19f, t.text, true))
        ht.addView(text("Penjelajahan bersih tanpa iklan", 12.5f, t.muted))
        head.addView(ht)
        sheet.addView(head, lp(MATCH, WRAP))

        // kartu statistik
        val total = netBlocked.get() + jsBlocked.get()
        val stat = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            background = shape(t.surface2, r(16))
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        fun statCol(n: String, label: String) = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            addView(text(n, 20f, t.accent, true).apply { gravity = Gravity.CENTER })
            addView(text(label, 11.5f, t.muted).apply { gravity = Gravity.CENTER })
        }
        stat.addView(statCol("$total", "iklan diblokir"), lp(0, WRAP, 1f))
        stat.addView(View(this).apply { setBackgroundColor(t.line) }, lp(1, dp(32)))
        stat.addView(statCol("$redirBlocked", "redirect dicegah"), lp(0, WRAP, 1f))
        stat.addView(View(this).apply { setBackgroundColor(t.line) }, lp(1, dp(32)))
        stat.addView(statCol(formatCount(AdBlocker.size), "domain di daftar"), lp(0, WRAP, 1f))
        sheet.addView(stat, lp(MATCH, WRAP).apply { topMargin = dp(16) })

        fun section(title: String) {
            sheet.addView(text(title.uppercase(), 11.5f, t.accent, true).apply {
                letterSpacing = 0.08f
            }, lp(MATCH, WRAP).apply { topMargin = dp(22); bottomMargin = dp(4) })
        }
        fun row(res: Int, title: String, sub: String?, trailing: View?, click: (() -> Unit)?): LinearLayout {
            val rowV = LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(4), dp(12), dp(4), dp(12))
                if (click != null) {
                    background = ripple(null, r(12))
                    isClickable = true
                    setOnClickListener { click() }
                }
            }
            val ib = FrameLayout(this).apply { background = shape(t.surface2, r(12)) }
            ib.addView(icon(res, t.text, 20), FrameLayout.LayoutParams(sz(20), sz(20), Gravity.CENTER))
            rowV.addView(ib, lp(sz(38), sz(38)))
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), 0, dp(10), 0) }
            col.addView(text(title, 15f, t.text))
            if (sub != null) col.addView(text(sub, 12.5f, t.muted))
            rowV.addView(col, lp(0, WRAP, 1f))
            if (trailing != null) rowV.addView(trailing)
            sheet.addView(rowV, lp(MATCH, WRAP))
            return rowV
        }
        fun toggle(res: Int, title: String, sub: String, value: Boolean, onChange: (Boolean) -> Unit) {
            val sw = Switch(this).apply {
                isChecked = value
                val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
                thumbTintList = ColorStateList(states, intArrayOf(t.accent, if (t.dark) t.muted else Color.WHITE))
                trackTintList = ColorStateList(states, intArrayOf(withAlpha(t.accent, 0x77), t.line))
                setOnCheckedChangeListener { _, v -> onChange(v) }
            }
            row(res, title, sub, sw) { sw.toggle() }
        }

        section("Perlindungan")
        toggle(R.drawable.ic_shield_check, "Shield", "Blokir iklan, popup, pelacak, dan redirect", shieldOn) {
            shieldOn = it; prefs.edit().putBoolean("shield", it).apply(); updateShield(); reload = true
        }
        toggle(R.drawable.ic_close, "Hapus overlay promo", "Modal iklan atau promo layar penuh", overlayOn) {
            overlayOn = it; prefs.edit().putBoolean("overlay", it).apply(); reload = true
        }
        toggle(R.drawable.ic_scroll, "Chapter berikutnya otomatis", "Muat lanjutan saat menggulir ke bawah", nextOn) {
            nextOn = it; prefs.edit().putBoolean("next", it).apply(); reload = true
        }

        section("Pencarian")
        val chips = LinearLayout(this)
        val chipViews = ArrayList<TextView>()
        fun paintChips() {
            Search.engines.forEachIndexed { i, (id, _) ->
                val on = id == engine
                chipViews[i].setTextColor(if (on) t.onAccent else t.text)
                chipViews[i].background = ripple(shape(if (on) t.accent else t.surface2, r(14), if (on) null else t.line), r(14))
            }
        }
        Search.engines.forEach { (id, name) ->
            val c = text(name, 13f, t.text, true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(4), dp(10), dp(4), dp(10))
                isClickable = true
                maxLines = 1
                setOnClickListener {
                    engine = id; prefs.edit().putString("engine", id).apply(); paintChips()
                    if (isHome()) reload = true
                }
            }
            chipViews.add(c)
            chips.addView(c, lp(0, WRAP, 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        }
        paintChips()
        sheet.addView(chips, lp(MATCH, WRAP).apply { topMargin = dp(8); bottomMargin = dp(4) })

        val regionValue = text(Search.regionName(region), 13.5f, t.muted)
        val trail = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(regionValue)
            addView(icon(R.drawable.ic_chevron, t.muted, 18))
        }
        val regionRow = row(R.drawable.ic_globe, "Wilayah hasil", "Negara asal hasil pencarian", trail) {
            val cur = Search.regions.indexOfFirst { it.first == region }.coerceAtLeast(0)
            pickSheet("Wilayah hasil", "Negara asal hasil pencarian", Search.regions.map { it.second to null }, cur) { i ->
                region = Search.regions[i].first
                prefs.edit().putString("region", region).apply()
                regionValue.text = Search.regionName(region)
                if (isHome()) web.reload()
            }
        }
        regionRow.tag = "region"
        toggle(R.drawable.ic_search, "SafeSearch", "Saring konten eksplisit di hasil pencarian", safeSearch) {
            safeSearch = it; prefs.edit().putBoolean("safe", it).apply(); if (isHome()) reload = true
        }

        val dnsValue = text(SecureDns.byId(dnsId).name.substringBefore(" "), 13.5f, t.muted)
        val dnsTrail = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(dnsValue)
            addView(icon(R.drawable.ic_chevron, t.muted, 18))
        }
        val dnsSub = when {
            !dnsSupported() -> "Butuh Android System WebView terbaru"
            SecureDns.endpoint != null && SecureDns.lookups > 0 && SecureDns.failures * 2 > SecureDns.lookups ->
                "Sering gagal di jaringan ini, coba penyedia lain"
            else -> "Lewati DNS operator yang memaksa SafeSearch"
        }
        row(R.drawable.ic_lock, "DNS aman", dnsSub, dnsTrail) {
            pickDns { dnsValue.text = SecureDns.byId(dnsId).name.substringBefore(" ") }
        }

        section("Tema")
        val themeHeader = sheet.getChildAt(sheet.childCount - 1)
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        Themes.all.chunked(2).forEach { pair ->
            val rowL = LinearLayout(this)
            pair.forEach { th ->
                rowL.addView(themeCard(th) {
                    if (th.id != t.id) {
                        prefs.edit().putString("theme", th.id).apply()
                        t = th
                        reopenThemes = true
                        d.dismiss()
                    }
                }, lp(0, WRAP, 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })
            }
            if (pair.size == 1) rowL.addView(View(this), lp(0, 1, 1f))
            grid.addView(rowL, lp(MATCH, WRAP))
        }
        sheet.addView(grid, lp(MATCH, WRAP))

        section("Data")
        toggle(R.drawable.ic_scroll, "Hemat data", "Video tidak diputar atau dimuat otomatis, chapter dimuat lebih dekat", saverOn) {
            saverOn = it; prefs.edit().putBoolean("saver", it).apply(); reload = true
        }
        val nowBytes = appBytes()
        val usage = if (nowBytes < 0 || sessionStart < 0) "Tidak tersedia di HP ini"
            else "Sejak dibuka: ${mb(nowBytes - sessionStart)} · latar belakang: ${mb(bgBytes)}"
        row(R.drawable.ic_globe, "Pemakaian data MiniBrowser", usage, null, null)
        row(R.drawable.ic_refresh_list, "Perbarui daftar iklan", "Sekitar 3 MB. Otomatis hanya lewat Wi-Fi", null) { updateList() }
        row(R.drawable.ic_trash, "Hapus data penjelajahan", "Cookie, cache, dan riwayat", null) {
            CookieManager.getInstance().removeAllCookies(null)
            WebStorage.getInstance().deleteAllData()
            web.clearCache(true)
            web.clearHistory()
            updateNav()
            toast("Data penjelajahan dihapus")
        }
        sheet.addView(text("MiniBrowser 1.5", 11.5f, t.muted).apply { gravity = Gravity.CENTER },
            lp(MATCH, WRAP).apply { topMargin = dp(18) })

        d.setOnDismissListener {
            if (reopenThemes) {
                buildUi()
                if (isHome()) web.reload()
                main.post { showSettings(true) }
            } else if (reload) web.reload()
        }
        val scroll = showSheet(d, sheet)
        if (scrollToThemes) scroll.post { scroll.scrollTo(0, themeHeader.top - dp(8)) }
    }

    private fun themeCard(th: Theme, click: () -> Unit): View {
        val sel = th.id == t.id
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = ripple(shape(t.surface2, r(16), if (sel) t.accent else t.line, if (sel) 2 else 1), r(16))
            setPadding(dp(8), dp(8), dp(8), dp(10))
            isClickable = true
            setOnClickListener { click() }
        }
        // pratinjau mini: menunjukkan letak bilah alamat & gaya dock tema itu
        val pr = minOf(th.radius, 14)
        val prev = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = shape(th.bg, dp(pr), th.line)
            setPadding(dp(5), dp(5), dp(5), dp(5))
        }
        fun bar() = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            background = shape(th.surface2, dp(minOf(th.radius, 8)), th.line)
            setPadding(dp(4), 0, dp(4), 0)
            addView(View(this@MainActivity).apply { background = shape(th.accent, dp(3)) }, lp(dp(6), dp(6)))
            addView(View(this@MainActivity).apply { background = shape(th.muted, dp(2)) },
                lp(0, dp(3), 1f).apply { marginStart = dp(4); marginEnd = dp(10) })
        }
        fun content() = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(2), dp(5), dp(2), dp(5))
            listOf(1f, 0.7f, 0.85f).forEach { w ->
                addView(View(this@MainActivity).apply { background = shape(th.line, dp(2)) },
                    lp(0, dp(4)).apply { width = (dp(100) * w).toInt(); bottomMargin = dp(4) })
            }
        }
        fun dockBar() = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            background = if (th.dock == Dock.FLOAT) shape(th.surface, dp(minOf(th.radius, 10)), th.line) else shape(th.surface, 0)
            repeat(4) {
                addView(View(this@MainActivity).apply { background = shape(th.muted, dp(2)) },
                    lp(dp(6), dp(6)).apply { setMargins(dp(4), 0, dp(4), 0) })
            }
        }
        if (!th.addrBottom) prev.addView(bar(), lp(MATCH, dp(14)))
        prev.addView(content(), lp(MATCH, 0, 1f))
        if (th.addrBottom) prev.addView(bar(), lp(MATCH, dp(14)).apply { bottomMargin = dp(4) })
        prev.addView(dockBar(), lp(if (th.dock == Dock.FLOAT) WRAP else MATCH, dp(12)).apply {
            gravity = Gravity.CENTER_HORIZONTAL
        })
        card.addView(prev, lp(MATCH, dp(92)))

        val nameRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        nameRow.addView(TextView(this).apply {
            text = th.name
            textSize = 13.5f
            setTextColor(t.text)
            typeface = th.font.typeface(true)
            maxLines = 1
        }, lp(0, WRAP, 1f))
        if (sel) nameRow.addView(icon(R.drawable.ic_check, t.accent, 16))
        card.addView(nameRow, lp(MATCH, WRAP).apply { topMargin = dp(8) })
        card.addView(TextView(this).apply {
            text = th.desc
            textSize = 11.5f
            setTextColor(t.muted)
            maxLines = 2
        })
        return card
    }

    private fun formatCount(n: Int) = if (n >= 1000) "${n / 1000}rb" else "$n"

    private fun isHome() = web.url?.startsWith("file:") == true

    private fun updateList() {
        toast("Mengunduh daftar iklan…")
        thread {
            val n = try { AdBlocker.update(this) } catch (_: Throwable) { -1 }
            main.post { if (!destroyed) toast(if (n > 0) "Daftar iklan diperbarui: ${formatCount(n)} domain" else "Gagal memperbarui daftar") }
        }
    }

    // ================================================================== navigasi

    private fun normalize(v0: String): String {
        val v = v0.trim()
        if (v.isEmpty()) return ""
        if (Regex("^https?://", RegexOption.IGNORE_CASE).containsMatchIn(v)) return v
        if (Regex("^[a-z0-9.-]+\\.[a-z]{2,}(/.*)?$", RegexOption.IGNORE_CASE).matches(v)) return "https://$v"
        return Search.url(engine, region, safeSearch, v)
    }

    private fun open(v: String) {
        val u = normalize(v)
        if (u.isEmpty()) return
        hideKeyboard()
        address.clearFocus()
        navOkAt = SystemClock.uptimeMillis()
        web.loadUrl(u)
    }

    // ================================================================== auto-scroll

    private fun toggleScroll() {
        if (isHome() || web.url == null) { toast("Buka halaman dulu"); return }
        scrollShown = !scrollShown
        scrolling = scrollShown
        applyScroll()
    }

    private fun setLevel(l: Int) {
        level = l.coerceIn(1, 10)
        prefs.edit().putInt("lvl", level).apply()
        applyScroll()
    }

    private fun applyScroll() {
        if (!::scrollBar.isInitialized) return
        if (scrollShown) fadeIn(scrollBar) else scrollBar.visibility = View.GONE
        lvlText.text = level.toString()
        playIcon.setImageResource(if (scrolling) R.drawable.ic_pause else R.drawable.ic_play)
        val v = if (scrolling && scrollShown) SPEEDS[level - 1] else 0
        web.evaluateJavascript("window.__mbScroll&&window.__mbScroll($v)", null)
        if (v > 0) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    // ================================================================== redirect

    private fun key(url: String): String {
        val u = Uri.parse(url)
        return (u.host ?: "").lowercase().removePrefix("www.") + (u.path ?: "").trimEnd('/')
    }

    private fun sameSite(a: String?, b: String?) = AdBlocker.reg(a) == AdBlocker.reg(b)

    private fun blockRedirect(url: String, canOpen: Boolean) {
        redirBlocked++
        val host = Uri.parse(url).host?.removePrefix("www.") ?: url.take(40)
        if (canOpen) showBanner("Redirect diblokir: $host", "Buka tetap") {
            navOkAt = SystemClock.uptimeMillis()
            web.loadUrl(url)
        } else showBanner("Iklan diblokir: $host")
    }

    // ================================================================== WebView

    @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
    private fun setupWeb() {
        shieldJs = assets.open("shield.js").bufferedReader().use { it.readText() }.replace("__MB_TOKEN__", token)

        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            loadWithOverviewMode = true
            useWideViewPort = true
            builtInZoomControls = true
            displayZoomControls = false
            mediaPlaybackRequiresUserGesture = true
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(true)
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        }
        // renderer boleh diturunkan prioritasnya saat aplikasi tidak terlihat
        if (Build.VERSION.SDK_INT >= 26) web.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, true)
        web.isVerticalScrollBarEnabled = false
        web.overScrollMode = View.OVER_SCROLL_NEVER
        web.setOnScrollChangeListener { _, _, y, _, oy ->
            val dy = y - oy
            if (dy > dp(6) && y > dp(120)) showDock(false)
            else if (dy < -dp(6)) showDock(true)
        }
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, false)

        web.addJavascriptInterface(Bridge(), "MBNative")
        web.addJavascriptInterface(HomeBridge(), "MBHome")

        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            WebViewCompat.addDocumentStartJavaScript(web, shieldJs, setOf("*"))
            docStart = true
        }

        web.webViewClient = object : WebViewClient() {

            override fun shouldInterceptRequest(view: WebView, req: WebResourceRequest): WebResourceResponse? {
                if (!shieldOn || req.isForMainFrame) return null
                val url = req.url.toString()
                if (!url.startsWith("http")) return null
                if (AdBlocker.isBlocked(url)) {
                    netBlocked.incrementAndGet()
                    return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                }
                return null
            }

            override fun shouldOverrideUrlLoading(view: WebView, req: WebResourceRequest): Boolean {
                val url = req.url.toString()
                val scheme = req.url.scheme?.lowercase() ?: ""

                if (!req.isForMainFrame) return shieldOn && AdBlocker.isBlocked(url)

                if (scheme != "http" && scheme != "https") {
                    if (scheme == "about" || scheme == "javascript" || scheme == "file" || scheme == "blob" || scheme == "data") return false
                    if (shieldOn && !req.hasGesture()) { blockRedirect(url, false); return true }
                    showBanner("Buka di aplikasi lain?", "Buka", 6000) {
                        try {
                            val i = if (scheme == "intent") Intent.parseUri(url, Intent.URI_INTENT_SCHEME) else Intent(Intent.ACTION_VIEW, req.url)
                            i.addCategory(Intent.CATEGORY_BROWSABLE)
                            i.component = null
                            i.selector = null
                            startActivity(i)
                        } catch (_: Exception) { toast("Tidak ada aplikasi untuk membuka link ini") }
                    }
                    return true
                }

                if (!shieldOn) return false

                val host = req.url.host
                if (AdBlocker.isBlocked(url)) { blockRedirect(url, false); return true }

                val cur = view.url
                val now = SystemClock.uptimeMillis()
                if (cur == null || cur.startsWith("file:") || cur == "about:blank") { navOkAt = now; return false }
                if (sameSite(host, Uri.parse(cur).host)) { navOkAt = now; return false }
                if (req.isRedirect && now - navOkAt < 8000) { navOkAt = now; return false }
                val k = allowKey
                if (req.hasGesture() && k != null && now - allowAt < 4000 && k == key(url)) {
                    allowKey = null; navOkAt = now; return false
                }
                blockRedirect(url, true)
                return true
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                showAddress(url)
                showDock(true)
                progress.visibility = View.VISIBLE
                if (scrolling) { scrolling = false; applyScroll() }
                updateNav()
            }

            override fun onPageCommitVisible(view: WebView, url: String?) {
                if (!docStart) view.evaluateJavascript(shieldJs, null)
            }

            override fun onPageFinished(view: WebView, url: String?) {
                progress.visibility = View.INVISIBLE
                if (!docStart) view.evaluateJavascript(shieldJs, null)
                updateNav()
            }

            /**
             * Proses halaman (renderer) mati, biasanya karena memori HP penuh oleh halaman berat.
             * Tanpa ini Android menutup seluruh aplikasi. Di sini WebView dibuat ulang saja.
             */
            override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
                if (view !== web) { try { view.destroy() } catch (_: Throwable) {}; return true }
                main.post { recoverWebView(detail.didCrash()) }
                return true
            }

            override fun doUpdateVisitedHistory(view: WebView, url: String?, isReload: Boolean) {
                showAddress(url)
                updateNav()
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, p: Int) {
                progress.progress = p
            }

            override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message): Boolean {
                if (shieldOn) {
                    jsBlocked.incrementAndGet()
                    return false
                }
                val tmp = WebView(this@MainActivity)
                tmp.webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                        web.loadUrl(r.url.toString())
                        v.destroy()
                        return true
                    }
                }
                (resultMsg.obj as WebView.WebViewTransport).webView = tmp
                resultMsg.sendToTarget()
                return true
            }
        }

        web.setDownloadListener { url, ua, cd, mime, _ ->
            val name = URLUtil.guessFileName(url, cd, mime)
            showBanner("Unduh $name?", "Unduh", 8000) {
                try {
                    val rq = DownloadManager.Request(Uri.parse(url)).apply {
                        setMimeType(mime)
                        addRequestHeader("User-Agent", ua)
                        CookieManager.getInstance().getCookie(url)?.let { addRequestHeader("Cookie", it) }
                        setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                        setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
                    }
                    (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(rq)
                    toast("Mengunduh $name")
                } catch (_: Exception) {
                    toast("Gagal mengunduh")
                }
            }
        }
    }

    private fun recoverWebView(crashed: Boolean) {
        if (destroyed) return
        val last = currentUrl ?: try { web.url } catch (_: Throwable) { null }
        val now = SystemClock.uptimeMillis()
        // kalau halaman yang sama langsung mati lagi, jangan diulang terus: kembali ke beranda
        val again = now - lastGoneAt < 15000
        lastGoneAt = now
        scrolling = false
        try {
            (web.parent as? ViewGroup)?.removeView(web)
            web.destroy()
        } catch (_: Throwable) {}
        web = WebView(this)
        setupWeb()
        buildUi()
        val u = if (again || last == null || !last.startsWith("http")) HOME else last
        web.loadUrl(u)
        showBanner(when {
            again -> "Halaman terlalu berat untuk HP ini, kembali ke beranda"
            crashed -> "Halaman bermasalah dan dimuat ulang"
            else -> "Memori HP penuh, halaman dimuat ulang"
        })
    }

    private fun hex(c: Int) = String.format("#%06X", c and 0xFFFFFF)

    /** Konfigurasi untuk halaman beranda (tema & pencarian). Tidak berisi data rahasia. */
    inner class HomeBridge {
        @JavascriptInterface
        fun config(): String {
            val th = t
            return JSONObject()
                .put("bg", hex(th.bg)).put("surface", hex(th.surface)).put("surface2", hex(th.surface2))
                .put("line", hex(th.line)).put("text", hex(th.text)).put("muted", hex(th.muted))
                .put("accent", hex(th.accent)).put("onAccent", hex(th.onAccent))
                .put("radius", th.radius).put("font", th.font.css).put("scale", th.scale.toDouble())
                .put("upper", th.upper).put("dark", th.dark)
                .put("search", Search.url(engine, region, safeSearch, "__Q__"))
                .put("engine", Search.engineName(engine))
                .put("region", Search.regionName(region))
                .put("safe", safeSearch)
                .put("shield", shieldOn)
                .put("blocked", netBlocked.get() + jsBlocked.get())
                .toString()
        }
    }

    /** Jembatan untuk skrip shield. Setiap panggilan wajib membawa token. */
    inner class Bridge {
        @JavascriptInterface
        fun cfg(tk: String): String =
            if (tk != token) "{}"
            else JSONObject().put("on", shieldOn).put("o", overlayOn).put("n", nextOn).put("d", saverOn).toString()

        @JavascriptInterface
        fun allow(tk: String, u: String) {
            if (tk != token) return
            allowKey = key(u)
            allowAt = SystemClock.uptimeMillis()
        }

        @JavascriptInterface
        fun add(tk: String, n: Int) {
            if (tk == token && n > 0) jsBlocked.addAndGet(n)
        }

        @JavascriptInterface
        fun redir(tk: String, u: String) {
            if (tk == token) main.post { blockRedirect(u, true) }
        }

        @JavascriptInterface
        fun cur(tk: String, u: String) {
            if (tk == token) main.post { showAddress(u) }
        }

        @JavascriptInterface
        fun scroll(tk: String, s: String) {
            if (tk != token) return
            main.post {
                scrolling = false
                applyScroll()
                if (s == "end") toast("Sampai di akhir halaman")
            }
        }

        @JavascriptInterface
        fun msg(tk: String, m: String) {
            if (tk == token) main.post { toast(m.take(120)) }
        }
    }
}
