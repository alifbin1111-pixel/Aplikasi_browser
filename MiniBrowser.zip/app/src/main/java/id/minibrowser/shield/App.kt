package id.minibrowser.shield

import android.app.Application
import android.os.Build
import android.util.Log
import java.io.File
import java.util.Date

/**
 * Penangkap error global.
 * - Error di thread latar milik aplikasi (proxy DNS, daftar iklan) tidak boleh menutup aplikasi.
 * - Error lain dicatat ke crash.txt supaya bisa disalin saat aplikasi dibuka lagi.
 */
class App : Application() {
    override fun onCreate() {
        super.onCreate()
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { th, e ->
            if (th.name.startsWith("mb-") && th !== mainLooper.thread) {
                Log.w("MiniBrowser", "error di ${th.name}", e)
                return@setDefaultUncaughtExceptionHandler
            }
            try {
                File(filesDir, "crash.txt").writeText(
                    "${Date()}\nMiniBrowser ${BuildConfigInfo.version(this)}\n" +
                        "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}) ${Build.MANUFACTURER} ${Build.MODEL}\n" +
                        "Thread: ${th.name}\n\n" + Log.getStackTraceString(e)
                )
            } catch (_: Throwable) {}
            prev?.uncaughtException(th, e)
        }
    }
}

object BuildConfigInfo {
    fun version(app: Application): String = try {
        app.packageManager.getPackageInfo(app.packageName, 0).versionName ?: "?"
    } catch (_: Throwable) { "?" }
}
