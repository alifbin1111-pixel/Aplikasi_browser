package id.minibrowser.shield

import android.graphics.Typeface

enum class Dock { LABELS, ICONS, FLOAT }

enum class Font(val css: String) {
    SANS("system-ui,-apple-system,Roboto,sans-serif"),
    MEDIUM("system-ui,-apple-system,Roboto,sans-serif"),
    SERIF("Georgia,'Noto Serif',serif"),
    MONO("'Roboto Mono','Droid Sans Mono',monospace"),
    CONDENSED("'Roboto Condensed','sans-serif-condensed',sans-serif");

    fun typeface(bold: Boolean = false): Typeface {
        val style = if (bold) Typeface.BOLD else Typeface.NORMAL
        return when (this) {
            SANS -> Typeface.create(if (bold) "sans-serif-medium" else "sans-serif", Typeface.NORMAL)
            MEDIUM -> Typeface.create("sans-serif-medium", style)
            SERIF -> Typeface.create(Typeface.SERIF, style)
            MONO -> Typeface.create(Typeface.MONOSPACE, style)
            CONDENSED -> Typeface.create("sans-serif-condensed", style)
        }
    }
}

/**
 * Tema bukan sekadar warna: tiap tema juga mengatur letak bilah alamat,
 * gaya dock, bentuk sudut, jenis huruf, dan kepadatan.
 */
data class Theme(
    val id: String,
    val name: String,
    val desc: String,
    val dark: Boolean,
    val bg: Int,
    val surface: Int,
    val surface2: Int,
    val line: Int,
    val text: Int,
    val muted: Int,
    val accent: Int,
    val onAccent: Int,
    val radius: Int,
    val addrBottom: Boolean,
    val dock: Dock,
    val font: Font,
    val scale: Float = 1f,
    val upper: Boolean = false,
    val boldLabels: Boolean = false
)

private fun c(v: Long) = v.toInt()

object Themes {
    val all = listOf(
        Theme("graphite", "Graphite", "Gelap netral, klasik", true,
            c(0xFF17191E), c(0xFF1F2228), c(0xFF272B33), c(0xFF343942), c(0xFFE8EAEE), c(0xFF9BA3B0), c(0xFF8AB4F8), c(0xFF0B1B33),
            22, false, Dock.LABELS, Font.SANS),
        Theme("kertas", "Kertas", "Terang hangat, huruf serif", false,
            c(0xFFF6F1E7), c(0xFFFBF8F1), c(0xFFEFE8DA), c(0xFFDDD3BF), c(0xFF2B2620), c(0xFF7A6F60), c(0xFF9C4A1A), c(0xFFFFFFFF),
            10, false, Dock.LABELS, Font.SERIF),
        Theme("samudra", "Samudra", "Biru laut, dock melayang", true,
            c(0xFF0B1724), c(0xFF0F2033), c(0xFF16304A), c(0xFF1F3F5E), c(0xFFE3F1FF), c(0xFF8FB0CC), c(0xFF38D9F5), c(0xFF04222B),
            24, false, Dock.FLOAT, Font.MEDIUM),
        Theme("amoled", "AMOLED", "Hitam pekat, alamat di bawah", true,
            c(0xFF000000), c(0xFF000000), c(0xFF141414), c(0xFF262626), c(0xFFF2F2F2), c(0xFF8C8C8C), c(0xFFFFFFFF), c(0xFF000000),
            18, true, Dock.ICONS, Font.SANS),
        Theme("mint", "Mint", "Terang segar, satu tangan", false,
            c(0xFFEEF7F2), c(0xFFFFFFFF), c(0xFFE3F1E9), c(0xFFCFE3D7), c(0xFF15302A), c(0xFF5E7D72), c(0xFF12A37B), c(0xFFFFFFFF),
            28, true, Dock.FLOAT, Font.SANS),
        Theme("senja", "Senja", "Ungu hangat, aksen jingga", true,
            c(0xFF1C1426), c(0xFF251A33), c(0xFF33243F), c(0xFF45324F), c(0xFFF6E9F0), c(0xFFB79FB5), c(0xFFFF8A5B), c(0xFF2A0E02),
            16, false, Dock.LABELS, Font.MEDIUM),
        Theme("terminal", "Terminal", "Monospace, sudut tegas", true,
            c(0xFF050805), c(0xFF0A0F0A), c(0xFF101A10), c(0xFF1E3A1E), c(0xFFB6FFB6), c(0xFF5FA35F), c(0xFF39FF6A), c(0xFF001A06),
            0, false, Dock.LABELS, Font.MONO, 0.95f, upper = true),
        Theme("nord", "Nord", "Abu kebiruan, ringkas", true,
            c(0xFF2E3440), c(0xFF3B4252), c(0xFF434C5E), c(0xFF4C566A), c(0xFFECEFF4), c(0xFFA3ABB9), c(0xFF88C0D0), c(0xFF1F2530),
            8, false, Dock.ICONS, Font.CONDENSED, 0.9f),
        Theme("sakura", "Sakura", "Merah muda lembut, bulat", false,
            c(0xFFFFF4F7), c(0xFFFFFFFF), c(0xFFFCE6EE), c(0xFFF5CFDC), c(0xFF3A1E2A), c(0xFF9A6B7C), c(0xFFE64980), c(0xFFFFFFFF),
            30, true, Dock.FLOAT, Font.SANS),
        Theme("kontras", "Kontras Tinggi", "Huruf besar, mudah dibaca", true,
            c(0xFF000000), c(0xFF000000), c(0xFF1A1A1A), c(0xFFFFE600), c(0xFFFFFFFF), c(0xFFFFE600), c(0xFFFFE600), c(0xFF000000),
            6, false, Dock.LABELS, Font.MEDIUM, 1.15f, boldLabels = true)
    )

    fun byId(id: String?) = all.firstOrNull { it.id == id } ?: all[0]
}
