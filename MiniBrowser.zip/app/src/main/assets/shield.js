/* MiniBrowser Shield: dijalankan sebelum skrip situs. Semua state disimpan di closure. */
(function (T) {
  "use strict";
  if (window.__mbShieldOn) return;
  try { Object.defineProperty(window, "__mbShieldOn", { value: 1 }); } catch (e) { window.__mbShieldOn = 1; }
  var N = window.MBNative;
  if (!N) return;
  var C = {};
  try { C = JSON.parse(N.cfg(T)); } catch (e) {}
  if (!C.on) return;

  var TOP = window.top === window;
  var reg = function (h) {
    var p = String(h || "").toLowerCase().replace(/^www\./, "").split(".");
    var n = p.length > 2 && /^(co|com|ac|or|go|net|org|gov|edu|sch|my|web|biz|ne)$/.test(p[p.length - 2]) ? 3 : 2;
    return p.slice(-n).join(".");
  };
  var same = function (u) { return reg(u.hostname) === reg(location.hostname); };

  /* penghitung blokir, dikirim bertahap */
  var pend = 0, pt = 0;
  var hit = function () {
    pend++;
    if (!pt) pt = setTimeout(function () { pt = 0; try { N.add(T, pend); } catch (e) {} pend = 0; }, 500);
  };
  var redir = function (u) { hit(); try { N.redir(T, String(u).slice(0, 300)); } catch (e) {} };

  /* fungsi yang dipatch tampak native */
  var fk = new WeakMap(), ts = Function.prototype.toString;
  Function.prototype.toString = function () { return fk.has(this) ? fk.get(this) : ts.call(this); };
  fk.set(Function.prototype.toString, "function toString() { [native code] }");
  var nat = function (f, n) { fk.set(f, "function " + n + "() { [native code] }"); return f; };

  /* stub global iklan agar deteksi adblock mengira iklan termuat */
  var noop = function () {};
  var chain = new Proxy(noop, { get: function (t, p) { return p === Symbol.toPrimitive ? function () { return ""; } : chain; }, apply: function () { return chain; }, construct: function () { return chain; } });
  try {
    if (!window.adsbygoogle) { var a = []; a.loaded = true; a.push = function () { return 0; }; window.adsbygoogle = a; }
    if (!window.googletag) window.googletag = new Proxy({ cmd: { push: function (f) { try { typeof f === "function" && f(); } catch (e) {} return 1; } }, apiReady: true, pubadsReady: true }, { get: function (t, p) { return p in t ? t[p] : chain; } });
    window.canRunAds = true;
  } catch (e) {}

  /* popup: kembalikan jendela palsu */
  window.open = nat(function open() {
    hit();
    return { closed: false, close: noop, focus: noop, blur: noop, postMessage: noop, location: { href: "about:blank", replace: noop, assign: noop }, document: { write: noop, writeln: noop, open: noop, close: noop } };
  }, "open");

  /* ---------- redirect lewat skrip ---------- */
  var scriptNav = function (u) {
    if (!/^https?:$/.test(u.protocol)) return false;
    if (!same(u)) { redir(u.href); return true; }
    location.href = u.href;
    return true;
  };
  var ac = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = nat(function click() {
    if (!this.hasAttribute("download") && (!this.isConnected || (this.target && !/^_(self|top|parent)$/i.test(this.target)))) {
      var u; try { u = new URL(this.href, location.href); } catch (e) { return; }
      if (scriptNav(u)) return;
    }
    return ac.call(this);
  }, "click");

  /* penjaga klik: fase capture, terdaftar sebelum skrip situs */
  var trap = function (a) {
    var r = a.getBoundingClientRect(), A = innerWidth * innerHeight;
    for (var x = a, i = 0; x && x.nodeType === 1 && i < 4; x = x.parentElement, i++) {
      if (+getComputedStyle(x).opacity < 0.05) return true;
    }
    var t = (a.innerText || "").trim();
    return r.width * r.height > 0.4 * A && t.length < 3 && !a.querySelector("img,picture,video,canvas,svg");
  };
  addEventListener("click", function (e) {
    var a = e.target && e.target.closest && e.target.closest("a[href]");
    if (!a || a.hasAttribute("download")) return;
    var u; try { u = new URL(a.href, location.href); } catch (x) { return; }
    if (!/^https?:$/.test(u.protocol)) return;
    if (!same(u) && (!e.isTrusted || trap(a))) {
      e.preventDefault(); e.stopImmediatePropagation(); redir(u.href); return;
    }
    if (!e.isTrusted) return;
    /* klik di dalam iframe (biasanya banner iklan) tidak memberi izin pindah situs */
    if (TOP) { try { N.allow(T, u.href); } catch (x) {} }
    /* target=_blank: buka di tab yang sama (popup diblokir aplikasi) */
    if (a.target && !/^_(self|top|parent)$/i.test(a.target)) { e.preventDefault(); location.href = u.href; }
  }, true);
  addEventListener("submit", function (e) {
    var f = e.target;
    if (!f || f.tagName !== "FORM" || !e.isTrusted) return;
    try { N.allow(T, new URL(f.getAttribute("action") || "", location.href).href); } catch (x) {}
  }, true);

  /* ---------- sapu elemen iklan & overlay ---------- */
  var SEL = 'ins.adsbygoogle,[id^="google_ads_"],[id^="div-gpt-ad"],[data-ad-slot],[data-google-query-id],[class~="ad"],[class~="ads"],[class*="advert"],[id*="advert"],[class*="ad-banner"],[class*="banner-ad"],[class*="ad-slot"],[class*="adslot"],[class*="ad-container"],[id*="ad-container"],[class*="sticky-ad"],[class*="adsense"],[id*="adsense"],[class*="popunder"],[id*="popunder"],[id^="ad-"],[id^="ads-"]';
  var hide = function (e) { e.__mb = 1; e.style.setProperty("display", "none", "important"); hit(); };
  var okSweep = function (e) {
    /* elemen kosong (umpan detektor) dibiarkan */
    return !e.__mb && e.children.length && !/^(HTML|BODY|MAIN|ARTICLE|HEADER|NAV)$/.test(e.tagName);
  };
  var sweepIn = function (root) {
    try {
      if (root.nodeType === 1 && root.matches(SEL) && okSweep(root)) hide(root);
      if (root.querySelectorAll) root.querySelectorAll(SEL).forEach(function (e) { if (okSweep(e)) hide(e); });
    } catch (e) {}
  };
  var PR = /promo|diskon|iklan|langganan|subscribe|premium|ad.?block|sponsor|daftar sekarang|deposit|slot|gacor|bonus/i;
  var kill = function () {
    if (!document.body) return;
    var A = innerWidth * innerHeight, k = 0, full = [];
    document.body.querySelectorAll(":scope > *,:scope > * > *,:scope > * > * > *").forEach(function (e) {
      if (e.__mb || e.__mbk) return;
      var cs = getComputedStyle(e);
      if (cs.position !== "fixed" && cs.position !== "absolute") { e.__mbk = 1; return; }
      var r = e.getBoundingClientRect(), a = r.width * r.height;
      if (a < 0.2 * A) return;
      var t = (e.textContent || "").trim();
      /* penangkap klik tak terlihat: tap pertama = redirect */
      if (a > 0.5 * A && cs.pointerEvents !== "none" && (+cs.opacity < 0.05 ||
          (!t && !e.querySelector("img,video,canvas,svg,picture,input,button") && /rgba\(0, 0, 0, 0\)|transparent/.test(cs.backgroundColor) && +cs.zIndex >= 100))) {
        hide(e); return;
      }
      if (!C.o || cs.position !== "fixed") return;
      if (t.length < 500 && (PR.test(t) || e.querySelector("iframe"))) { hide(e); k++; }
      else if (!t && a > 0.8 * A) full.push(e);
    });
    if (k) {
      full.forEach(function (e) { e.style.setProperty("display", "none", "important"); });
      [document.documentElement, document.body].forEach(function (x) { x.style.setProperty("overflow", "auto", "important"); });
    }
  };

  /* Hemat CPU: perubahan DOM dikumpulkan lalu diproses paling sering tiap ~0,7 detik,
     hanya pada node yang baru masuk, dan berhenti total saat halaman tidak terlihat.
     Di dalam iframe (biasanya iklan) penyapuan tidak dijalankan sama sekali. */
  if (TOP) {
    var queue = [], qt = 0, lastKill = 0;
    var flush = function () {
      qt = 0;
      if (document.hidden) return;
      var q = queue; queue = [];
      for (var i = 0; i < q.length; i++) if (q[i].isConnected) sweepIn(q[i]);
      var now = Date.now();
      if (now - lastKill > 1200) { lastKill = now; kill(); }
    };
    var schedule = function () {
      if (qt) return;
      qt = setTimeout(function () {
        if (window.requestIdleCallback) requestIdleCallback(flush, { timeout: 800 }); else flush();
      }, 700);
    };
    new MutationObserver(function (ms) {
      for (var i = 0; i < ms.length; i++) {
        var add = ms[i].addedNodes;
        for (var j = 0; j < add.length; j++) if (add[j].nodeType === 1) queue.push(add[j]);
      }
      if (queue.length > 400) queue = [document.documentElement];
      if (queue.length) schedule();
    }).observe(document, { childList: true, subtree: true });
    document.addEventListener("DOMContentLoaded", function () { sweepIn(document); });
    addEventListener("load", function () {
      sweepIn(document); kill();
      [1500, 4000].forEach(function (t) { setTimeout(function () { if (!document.hidden) { sweepIn(document); kill(); } }, t); });
    });
  }

  if (!TOP) return;

  /* ---------- auto-scroll (dikendalikan aplikasi) ---------- */
  var sp = 0, last = 0, acc = 0, end = 0, rq = 0;
  var tick = function (t) {
    if (!sp) { rq = 0; return; }
    if (last) { acc += sp * (t - last) / 1000; var d = Math.trunc(acc); if (d) { scrollBy(0, d); acc -= d; } }
    last = t;
    var el = document.scrollingElement || document.documentElement;
    if (innerHeight + scrollY >= el.scrollHeight - 2) {
      if (++end > 90) { sp = 0; rq = 0; try { N.scroll(T, "end"); } catch (e) {} return; }
    } else end = 0;
    rq = requestAnimationFrame(tick);
  };
  window.__mbScroll = function (v) {
    sp = +v || 0; last = 0; acc = 0; end = 0;
    if (sp && !rq) rq = requestAnimationFrame(tick);
  };
  var stopUser = function () { if (sp) { sp = 0; try { N.scroll(T, "stop"); } catch (e) {} } };
  document.addEventListener("visibilitychange", function () { if (document.hidden) stopUser(); });
  addEventListener("touchstart", stopUser, { passive: true, capture: true });

  /* ---------- chapter berikutnya otomatis ---------- */
  if (!C.n) return;
  var readerOf = function (d) {
    var best = null, bs = 2;
    d.querySelectorAll("div,section,article,main").forEach(function (e) {
      var n = e.querySelectorAll(":scope > img").length + e.querySelectorAll(":scope > * > img").length;
      if (n >= 3 && n >= bs) { best = e; bs = n; }
    });
    return best;
  };
  var findNext = function (d, base) {
    var a = d.querySelector('link[rel~="next"],a[rel~="next"]');
    var h = a && a.getAttribute("href");
    if (!h) {
      var all = d.querySelectorAll("a[href]");
      for (var i = 0; i < all.length; i++) {
        var x = all[i];
        var t = (x.textContent || "").trim().toLowerCase().replace(/\s+/g, " ");
        var c = (String(x.className || "") + " " + x.id).toLowerCase();
        if (t.length <= 40 && (/^(next|selanjutnya|berikutnya|lanjut)/.test(t) || /(next|selanjutnya)\s*(chapter|chap|ch)/.test(t) || /\bnext\b/.test(c))) { h = x.getAttribute("href"); break; }
      }
    }
    try { return h && !/^(#|javascript|mailto)/i.test(h) ? new URL(h, base).href : ""; } catch (e) { return ""; }
  };
  var rd = null, next = "", ld = 0, off = 0, anc = null, lu = "", marks = [];
  var fixImg = function (i, base) {
    ["src", "data-src", "data-lazy-src", "data-original"].forEach(function (a) {
      var v = i.getAttribute(a);
      if (v && !/^data:/i.test(v)) { try { i.setAttribute(a, new URL(v, base).href); } catch (e) {} }
    });
    i.removeAttribute("srcset"); i.removeAttribute("sizes"); i.removeAttribute("loading");
    var ds = i.getAttribute("data-src") || i.getAttribute("data-lazy-src") || i.getAttribute("data-original");
    var sr = i.getAttribute("src") || "";
    if (ds && (!sr || /^data:/.test(sr))) i.setAttribute("src", ds);
  };
  var chk = function () {
    if (!rd || ld || off) return;
    var el = document.scrollingElement || document.documentElement;
    if (scrollY + innerHeight * 2.5 < el.scrollHeight) return;
    if (!next) { off = 1; return; }
    ld = 1;
    var u = next;
    fetch(u, { credentials: "include" }).then(function (r) {
      if (!r.ok) throw 0;
      return r.text();
    }).then(function (h) {
      var d = new DOMParser().parseFromString(h, "text/html");
      var r2 = readerOf(d);
      if (!r2) throw 0;
      r2.querySelectorAll("script,iframe,ins,noscript").forEach(function (x) { x.remove(); });
      r2.querySelectorAll("img").forEach(function (i) { fixImg(i, u); });
      var sep = document.createElement("div");
      sep.textContent = (d.title || "Chapter berikutnya").slice(0, 70);
      sep.style.cssText = "padding:20px 12px;text-align:center;font:600 13px system-ui,sans-serif;color:#888;background:rgba(127,127,127,.15);clear:both";
      var node = document.importNode(r2, true);
      node.setAttribute("data-mbc", "1");
      (anc || rd).after(sep, node);
      anc = node;
      marks.push({ el: sep, u: u });
      next = findNext(d, u);
      if (!next) off = 1;
      ld = 0;
      setTimeout(chk, 500);
    }).catch(function () {
      ld = 0; off = 1;
      try { N.msg(T, "Gagal memuat chapter berikutnya"); } catch (e) {}
      setTimeout(function () { off = 0; }, 8000);
    });
  };
  var trk = function () {
    if (marks.length < 2) return;
    var u = marks[0].u;
    for (var i = 0; i < marks.length; i++) if (marks[i].el.getBoundingClientRect().top <= innerHeight * 0.4) u = marks[i].u;
    if (u !== lu) { lu = u; try { N.cur(T, u); } catch (e) {} }
  };
  /* Hemat memori: gambar chapter yang sudah jauh di atas layar dilepas (diganti
     placeholder setinggi aslinya) lalu dimuat lagi saat kembali didekati.
     Membaca puluhan chapter tetap ringan dan HP tidak panas. */
  var GIF = "data:image/gif;base64,R0lGODlhAQABAAAAACw=";
  var lastUnload = 0, ut = 0;
  var unloadFar = function () {
    if (marks.length < 2) return;
    var now = Date.now();
    if (now - lastUnload < 600) {
      /* panggilan terakhir tetap dijalankan, supaya gambar kembali dimuat setelah lompat ke atas */
      if (!ut) ut = setTimeout(function () { ut = 0; unloadFar(); }, 600 - (now - lastUnload));
      return;
    }
    lastUnload = now;
    var far = innerHeight * 4, drop = [], back = [];
    document.querySelectorAll("[data-mbc] img").forEach(function (i) {
      var r = i.getBoundingClientRect();
      if (i.dataset.mbsrc) { if (r.bottom > -far * 0.75 && r.top < innerHeight + far) back.push(i); }
      else if (r.bottom < -far && r.height > 50 && i.complete && i.currentSrc) drop.push([i, r.height]);
    });
    drop.forEach(function (x) {
      var i = x[0];
      i.style.height = x[1] + "px";
      i.dataset.mbsrc = i.currentSrc;
      i.src = GIF;
    });
    back.forEach(function (i) { i.src = i.dataset.mbsrc; delete i.dataset.mbsrc; });
  };
  var init = function () {
    rd = readerOf(document);
    if (!rd) return;
    rd.setAttribute("data-mbc", "1");
    next = findNext(document, location.href);
    marks.push({ el: rd, u: location.href });
    setTimeout(chk, 800);
  };
  var st = 0;
  addEventListener("scroll", function () {
    if (st) return;
    st = setTimeout(function () { st = 0; chk(); trk(); unloadFar(); }, 120);
  }, { passive: true });
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})("__MB_TOKEN__");
