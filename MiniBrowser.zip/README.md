# MiniBrowser (Android)

Browser WebView dengan pemblokir iklan level jaringan, anti-redirect, auto-scroll,
dan chapter berikutnya otomatis. Tidak butuh proxy.

## Build lewat GitHub dari HP
1. Buat repo baru di github.com/new.
2. Add file → Create new file → nama `.github/workflows/build.yml`,
   tempel isi file `build.yml`, lalu Commit.
3. Add file → Upload files → unggah `MiniBrowser.zip` apa adanya (jangan diekstrak), Commit.
4. Tab Actions → tunggu "Build APK" hijau (±5 menit) → buka → Artifacts → MiniBrowser-apk.
5. Ekstrak zip-nya, pasang `app-release.apk`.

## Build di komputer
Buka folder ini di Android Studio, lalu Run. Atau: `gradle assembleRelease`.

## Cara kerja
- Iklan: setiap permintaan dicek di `shouldInterceptRequest` terhadap daftar bawaan
  + daftar StevenBlack (diunduh otomatis tiap 7 hari, bisa manual dari Menu).
- Redirect: perpindahan ke situs lain hanya diizinkan kalau berasal dari link yang
  benar-benar diketuk. Selain itu diblokir, dengan tombol "Buka tetap".
- Popup dan link ke Play Store/aplikasi lain dari iklan diblokir.
- `assets/shield.js` dijalankan sebelum skrip situs: hapus elemen iklan, overlay,
  lapisan penangkap klik, auto-scroll, dan chapter berikutnya.

## Versi 1.1
- UI baru dengan ikon vektor, lembar pengaturan, dan logo adaptif.
- 10 tema dengan tata letak berbeda (Menu → Tema).
- Pencarian: Google/Bing/DuckDuckGo/Brave, wilayah hasil (default Singapura), SafeSearch bisa diatur (default mati).

## Versi 1.2
- DNS aman (DNS-over-HTTPS) di Menu → Pencarian → DNS aman. Default Cloudflare 1.1.1.1.
  Pilihan: Cloudflare, Cloudflare Security, AdGuard, AdGuard Tanpa Filter, Google, Quad9, Mullvad, Mullvad Adblock, atau DNS sistem.
- Cara kerja: proxy lokal 127.0.0.1 (ProxyController) mencari IP lewat DoH. HTTPS tetap terenkripsi ujung ke ujung.

## Versi 1.3
- UI: pilihan wilayah & DNS memakai lembar bertema, lembar pengaturan tanpa lompatan ukuran,
  dock melayang otomatis sembunyi saat menggulir/mengetik, label dock tidak terpotong, tanpa kilatan gelap di tema terang.
- Performa: timer JS berhenti di latar belakang, penyapu iklan dibatasi & tidak jalan di iframe,
  gambar chapter jauh di atas dilepas dari memori, cache keputusan blokir, DNS tanpa kueri ganda, R8.

## Versi 1.4 (perbaikan aplikasi tertutup sendiri)
- Renderer WebView yang mati (memori penuh) dipulihkan, tidak lagi menutup aplikasi.
- Tidak menyimpan riwayat WebView ke Bundle (TransactionTooLargeException saat ke latar).
- Daftar iklan disimpan sebagai hash 64-bit: ±1,6 MB, bukan puluhan MB.
- Error di thread latar tidak menutup aplikasi; error lain dicatat dan bisa disalin saat dibuka lagi.

## Versi 1.5 (hemat kuota)
- 15 detik setelah aplikasi ke latar belakang: pemuatan dihentikan dan proxy memutus semua aliran data.
- Pembaruan daftar iklan otomatis hanya lewat Wi-Fi, paling sering sekali sehari mencoba.
- Mode Hemat data (default aktif): video tidak dimuat/diputar otomatis, chapter dimuat lebih dekat.
- Chapter gagal dimuat maksimal dicoba 3 kali dengan jeda makin lama.
- Menu → Data menampilkan pemakaian data MiniBrowser (dipakai & latar belakang).
